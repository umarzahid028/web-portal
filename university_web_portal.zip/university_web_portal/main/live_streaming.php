<?php 
require_once 'includes/init.php';
require_once  __DIR__.'/session.php';
require_once('header.php'); 
require_once('css.php'); 

if (isset($_SESSION['logged_in'])) {
      if ($_SESSION['logged_in']['account_type'] == 'instructor') {
           
           return header("Location: ../instructor/profile.php");
      }
      elseif ($_SESSION['logged_in']['account_type'] == 'student') {
          
           //return header("Location: index.php");
      } 
      elseif ($_SESSION['logged_in']['account_type'] == 'admin') {
          
           return header("Location: ../admin/index.php");
      } 
 } 
?>
<style type="text/css">
  .nav_color{background-color: #000000;}
</style>
  <body class="nav-sm" style="background-image:url(../banner1.jpg);">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view nav_color">
            <div class="navbar nav_title nav_color">
              <a href="index.php" class="site_title"><i class="fa fa-university"></i></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile">
              <div class="profile_pic">
                <img src="../public/images/user.png" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2>Admin</h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />
            <?php require_once('sidebar_nav.php'); ?>   
        <!-- page content -->
        <div class="right_col" role="main" style="background-color:transparent;">
          <div class="">
            <div class="page-title">
              <div class="title_left">
              </div>
              </div>
            </div>

            

            <div class="">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel" style="background:rgba(1, 2, 1, 0.6);">
                 <div class="clearfix"></div>
                  <div class="x_content">
                    <div class="row">
                          <video width="70%"  autoplay>
                            <source src="https://www.youtube.com/watch?v=7IZNH2jbThU">
                          </video>
                    </div>

					           
                        
                      </div>
                    </div>

                  </div>
                </div>
              </div>                
          <div class="clearfix"></div>
        </div>
        <!-- /page content -->

        
      </div>
    </div>

<!-- footer content -->
       <?php require_once('footer.php');?>
        <!-- /footer content --><!-- jQuery -->
    
<!-- JavaScript files --> 
  <?php require_once('js.php');?>
 <!-- JavaScript files-->



                                                                                 