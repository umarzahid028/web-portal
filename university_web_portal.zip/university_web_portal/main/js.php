 <!-- jQuery -->
    <script src="../public/js/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../public/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../public/js/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../public/js/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../public/js/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="../public/js/jquery.dataTables.min.js"></script>
    <script src="../public/js/dataTables.bootstrap.min.js"></script>
    <script src="../public/js/dataTables.buttons.min.js"></script>
    <script src="../public/js/jquery.inputmask.bundle.min.js"></script>
    <script src="../public/js/buttons.bootstrap.min.js"></script>
    <script src="../public/js/buttons.flash.min.js"></script>
    <script src="../public/js/buttons.html5.min.js"></script>
    <script src="../public/js/buttons.print.js"></script>
    <script src="../public/js/dataTables.fixedHeader.min.js"></script>
    <script src="../public/js/dataTables.keyTable.min.js"></script>
    <script src="../public/js/dataTables.responsive.min.js"></script>
    <script src="../public/js/responsive.bootstrap.js"></script>
    <script src="../public/js/datatables.scroller.min.js"></script>
    <script src="../public/js/jszip.min.js"></script>
    <script src="../public/js/pdfmake.min.js"></script>
    <script src="../public/js/vfs_fonts.js"></script>
    <!-- jQuery custom content scroller -->
    <script src="../public/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="../public/js/Chart.min.js"></script>
    <!-- jQuery Sparklines -->
    <script src="../public/js/jquery.sparkline.min.js"></script>
    <!-- Flot -->
    <script src="../public/js/jquery.flot.js"></script>
    <script src="../public/js/jquery.flot.pie.js"></script>
    <script src="../public/js/jquery.flot.time.js"></script>
    <script src="../public/js/jquery.flot.stack.js"></script>
    <script src="../public/js/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="../public/js/jquery.flot.orderBars.js"></script>
    <script src="../public/js/jquery.flot.spline.min.js"></script>
    <script src="../public/js/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="../public/js/date.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../public/js/custom.min.js"></script>
    <!-- Select2 -->
    <script src="../public/js/select2.full.min.js"></script>


    <script src="../public/js/dropzone.min.js"></script>
    <!-- Custom  Scripts -->
    <script src="../public/js/script.js"></script>



    

