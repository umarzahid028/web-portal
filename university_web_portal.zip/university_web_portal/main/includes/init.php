<?php
session_start();
require_once __DIR__.'/../../vendor/autoload.php';
require_once __DIR__.'/../functions/function.php';
require_once 'db.connection.php';  
require_once __DIR__.'/../classes/Student.php';
require_once __DIR__.'/../classes/Instructor.php';
require_once __DIR__.'/../classes/Admin.php';


