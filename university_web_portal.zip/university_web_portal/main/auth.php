<?php 
require_once 'includes/init.php';

$status = $student->login($_POST, $db);

if ($status === 'success') {
    echo json_encode([
        'success'=>'success',
        'message'=>'<div class="success">Authenticate Successfully !</div>',
        'url'=>'main/index.php'
    ]);
}
else if ($status === 'input_missing') {
    echo json_encode([
        'error'=>'error',
        'message'=>'<div class="error">All fields mandatory !</div>'
    ]);
}
else if ($status === 'error') {
    echo json_encode([
        'error'=>'error',
        'message'=>'<div class="error">Incorrect id or password!</div>'
    ]);
}