<?php require_once 'includes/init.php'; 
  
  if ($_SESSION['logged_in']['account_type'] == 'student') { ?>

    <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu nav_color" >
              <div class="menu_section">
                <h3>GENERAL</h3>
                <ul class="nav side-menu">
                  <li><a href="instructor_messages.php"><i class="fa fa-wechat"></i>Instructor Messages</a></li> 
                  
                  <li><a href="#"><i class="fa fa-weixin"></i>Online Chat</a></li>
                  <li><a href="academics_result.php"><i class="fa fa-shield"></i>Academics Result</a></li>
                  <li><a href="change_password.php"><i class="fa fa-unlock"></i>Password change</a></li>  
                </ul>
                
              </div>
              <div class="menu_section">
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-book"></i> Digital Library <span class="fa fa-chevron-down"></span></a>
                  </li>
                   <li><a href="live_streaming.php"><i class="fa fa-file-video-o"></i>Live</a>
                  </li>
                  
                  <li><a href="javascript:void(0)"><i class="fa fa-laptop"></i> Landing Page <span class="label label-success pull-right">Coming Soon</span></a></li>
                  
                  
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->

             <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" href="ChangePassword.php" data-placement="top" title="Settings"><hre
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" href="logoff.php" data-placement="top" title="Logout">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu" style="background:rgba(1, 2, 1, 0.6);
  border-radius:50px 1px 50px 2px;">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="../public/images/user.png" alt=""> Welcome:<strong> <?php echo $_SESSION['logged_in']['fullname'] ?> </strong>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="index.php"> Profile</a></li>
                    <li><a href="javascript:;">Help</a></li>
                    <li><a href="logoff.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                  </ul>
                </li>

                
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

<?php }
elseif ($_SESSION['logged_in']['account_type'] == 'instructor') {?>
   
    <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu nav_color" >
              <div class="menu_section">
                <h3>GENERAL</h3>
                <ul class="nav side-menu">
                  <li><a href="assignment.php"><i class="fa fa-pencil-square-o"></i>Assignment</a></li> 
                  <li><a href="instructor_messages.php"><i class="fa fa-bullhorn"></i>Announce-ment</a></li>
                  <li><a href="#"><i class="fa fa-weixin"></i>Online Chat</a></li>
                  
                  <li><a href="change_password.php"><i class="fa fa-unlock"></i>Password change</a></li>  
                </ul>
                
              </div>
              <div class="menu_section">
                <ul class="nav side-menu">
                   <li><a href="live_streaming.php"><i class="fa fa-file-video-o"></i>Live</a>
                  </li>
                  
                  <li><a href="javascript:void(0)"><i class="fa fa-laptop"></i> Landing Page <span class="label label-success pull-right">Coming Soon</span></a></li>
                  
                  
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->

             <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" href="ChangePassword.php" data-placement="top" title="Settings"><hre
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" href="../main/logoff.php" data-placement="top" title="Logout">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu" style="background:rgba(1, 2, 1, 0.6);
  border-radius:50px 1px 50px 2px;">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="../public/images/user.png" alt=""> Welcome:<strong> <?php echo $_SESSION['logged_in']['fullname'] ?> </strong>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="index.php"> Profile</a></li>
                    <li><a href="javascript:;">Help</a></li>
                    <li><a href="../main/logoff.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                  </ul>
                </li>

                
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

  
<?php }

else{ $_SESSION['logged_in']['account_type'] == 'admin'; ?>
   
    <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu nav_color" >
              <div class="menu_section">
                <h3>GENERAL</h3>
                <ul class="nav side-menu">
                  <li><a href="add-department.php"><i class="fa fa-graduation-cap"></i>Add Departmeny</a>
                  <li><a href="add-classes.php"><i class="fa fa-pencil-square-o"></i>Add Classes</a>
                  <li><a href="add-subject.php"><i class="fa fa-book"></i>Add Subject</a>
                  <li><a href="add-instructor.php"><i class="fa fa-user"></i>Add Instructor</a>
                  <li><a href="add-student.php"><i class="fa fa-child"></i>Add Student</a>
                  <li><a href="add-academic-result.php"><i class="fa fa-line-chart"></i>Academic Result</a>
                  <li><a href="add-attendance.php"><i class="fa fa-newspaper-o"></i>Attendance</a>
                  <li><a href="add-time-table.php"><i class="fa fa-clock-o"></i>Time Table</a>
                  <li><a href="add-fee.php"><i class="fa fa-money"></i>Fee Details</a>
                  <li><a href="add-date-sheet.php"><i class="fa fa-table"></i>Date Sheet</a>
                  <li><a href="add-university-notices.php"><i class="fa fa-bullhorn"></i>Notice Board</a>
                  

                  <li><a href="change_password.php"><i class="fa fa-unlock"></i>Password change</a></li>  
                </ul>
                
              </div>
              <div class="menu_section">
                <ul class="nav side-menu">
                   <li><a href="#"><i class="fa fa-file-video-o"></i>Live</a>
                  </li>
                  
                  <li><a href="javascript:void(0)"><i class="fa fa-laptop"></i> Landing Page <span class="label label-success pull-right">Coming Soon</span></a></li>
                  
                  
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->

             <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" href="ChangePassword.php" data-placement="top" title="Settings"><hre
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" href="../main/logoff.php" data-placement="top" title="Logout">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu" style="background:rgba(1, 2, 1, 0.6);
  border-radius:50px 1px 50px 2px;">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="../public/images/user.png" alt=""> Welcome:<strong> <?php echo $_SESSION['logged_in']['fullname'] ?> </strong>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="index.php"> Profile</a></li>
                    <li><a href="javascript:;">Help</a></li>
                    <li><a href="../main/logoff.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                  </ul>
                </li>

                
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->
<?php
}



    
