
 <link href="../public/css/jquery.mCustomScrollbar.min.css" rel="stylesheet"/>
    <!-- Bootstrap -->
    <link href="../public/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../public/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../public/css/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../public/css/green.css" rel="stylesheet">
    <!-- Datatables -->
    <link href="../public/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../public/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../public/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../public/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../public/css/scroller.bootstrap.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../public/css/custom.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../public/css/select2.min.css" rel="stylesheet">
    <link href="../public/css/dropzone.min.css" rel="stylesheet">