<?php 
require_once 'includes/init.php';

$status = $student->updateResetPassword($_POST, $db);

if ($status === 'success') {
    echo json_encode([
        'success'=>'success',
        'message'=>'<div class="success">Your Password Recover Successfully !</div>',
        'url'=>'main/index.php'
    ]);
}
else if ($status === 'input_missing') {
    echo json_encode([
        'error'=>'error',
        'message'=>'<div class="error">All fields mandatory !</div>'
    ]);
}
else if ($status === 'mismatch_password') {
    echo json_encode([
        'error'=>'error',
        'message'=>'<div class="error">Should be the same new password and confirm new password!</div>'
    ]);
}
else if ($status === 'incorrect_id') {
    echo json_encode([
        'error'=>'error',
        'message'=>'<div class="error">This request can not be identifier</div>'
    ]);
}
else if ($status === 'incorrect_code') {
    echo json_encode([
        'error'=>'error',
        'message'=>'<div class="error">Request expired. We resent you an email!</div>'
    ]);
}

else if ($status === 'error') {
    echo json_encode([
        'error'=>'error',
        'message'=>'<div class="error">something wrong</div>'
    ]);
}

