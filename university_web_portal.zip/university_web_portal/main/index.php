<?php
require_once 'includes/init.php';
require_once  __DIR__.'/session.php';
require_once('header.php'); 
require_once('css.php'); 
 
if (isset($_SESSION['logged_in'])) {
      if ($_SESSION['logged_in']['account_type'] == 'instructor') {
           
           return header("Location: profile.php");
      }
      elseif ($_SESSION['logged_in']['account_type'] == 'student') {
          
           //return header("Location: index.php");
      } 
      elseif ($_SESSION['logged_in']['account_type'] == 'admin') {
          
           return header("Location: ../admin/index.php");
      } 
 } 


?>
<style type="text/css">
  .nav_color{background-color: #000000;}
</style>
  <body class="nav-sm" style="background-image:url(../banner1.jpg);">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view nav_color">
            <div class="navbar nav_title nav_color">
              <a href="index.php" class="site_title"><i class="fa fa-university"></i></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile">
              <div class="profile_pic">
                <img src="../public/images/user.png" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2>Admin</h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />
            <?php require_once('sidebar_nav.php'); 
            $session = $_SESSION['logged_in']['id'];
            $status = $student->getStudentinfo($session, $db);
            $arg = $status->st_class_id;
            $section = $status->st_section;

            ?>  


        <!-- page content -->
        <div class="right_col" role="main" style="background-color:transparent;">
          <div class="">
            <div class="page-title">
              <div class="title_left">
              </div>
              </div>
            </div>

            

            <div class="">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel" style="background:rgba(1, 2, 1, 0.6);">
                  
                    
                    
                    <div class="clearfix"></div>
                  
                  <div class="x_content">
            

					
					

	
			



                    <div class="" role="tabpanel" data-example-id="togglable-tabs">
                      <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist" style="background:rgba(1, 2, 1, 0.6); border-radius:50px 50px 50px 50px; border-color:#999;">
                        <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">My Profile </a></li>
        <li role="presentation" class=""><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Subject Enroll</a></li>
        <li role="presentation" class=""><a href="#tab_content3" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">Time Table</a></li>
        <li role="presentation" class=""><a href="#tab_content4" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Attendance</a></li>
       <li role="presentation" class=""><a href="#tab_content5" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Assignments</a></li>
       <li role="presentation" class=""><a href="#tab_content6" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Fee Detail</a></li>
      <li role="presentation" class=""><a href="#tab_content7" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Date Sheet</a></li>
      <li role="presentation" class=""><a href="#tab_content8" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Academics Report</a></li>
      <li role="presentation" class=""><a href="#tab_content9" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Notices</a></li>                        
                       
                      </ul>
                      <div id="myTabContent" class="tab-content">
                        <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
                        
        
        
              
            <!-- My profile -->
       
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>My Profile</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
                          <img class="img-responsive avatar-view" src="../public/images/user.png" alt="Avatar" title="<?php echo $status->st_fullname?>">
                        </div>
                      </div>
                      <h3><?php echo $status->st_fullname?></h3>

                      <ul class="list-unstyled user_data">
                        <li>
                          <i class="fa fa-envelope" aria-hidden="true"></i>
                            <?php echo $status->st_email?>
                        </li>

                        <li>
                          <i class="fa fa-briefcase user-profile-icon"></i> <?php echo $status->class_name?>
                        </li>

                        <li class="m-top-xs">
                          <i class="fa fa-external-link user-profile-icon"></i>
                          <a href="#" target="_blank">superior.edu.pk</a>
                        </li>
                      </ul>

        

                      
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12">

                      <div class="" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                          <li role="presentation" class="active"><a href="#tab_profile2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Personal info</a>
                          </li>
                          <li role="presentation" ><a href="#tab_profile3" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">University </a>
                          </li>
                        </ul>
                        <div id="myTabContent" class="tab-content">
                          
                          <div role="tabpanel" class="tab-pane fade active in" id="tab_profile2" aria-labelledby="profile-tab">

                            
                            <table class="data table table-striped no-margin">
                              <tbody>
                                <tr>
                                  <td><b>Full Name</b></td>
                                  <td><?php echo $status->st_fullname?></td>
                                  
                                </tr>
                                <tr>
                                  <td><b>Father Name </b></td>
                                  <td><?php echo $status->st_father_name?></td>
                                  
                                </tr>
                                <tr>
                                  <td><b>Gender</b></td>
                                  <td><?php echo $status->st_gender?></td>
                                </tr>
                                <tr>
                                  <td><b>Department </b></td>
                                  <td><?php echo $status->department_name?></td>
                                </tr>
                                <tr>
                                  <td><b>Degree </b></td>
                                  <td><?php echo $status->class_name?></td>
                                </tr>
                                <tr>
                                  <td><b>Section</b></td>
                                  <td><?php echo $status->st_section?></td>
                                </tr>
                                <tr>
                                  <td><b>Roll NO</b></td>
                                  <td><?php echo $status->st_roll_no?></td>
                                </tr>
                                <tr>
                                  <td><b>Registation NO</b></td>
                                  <td><?php echo $status->st_registation_no?></td>
                                  
                                </tr>
                                <tr>
                                  <td><b>Student Session</b></td>
                                  <td><?php echo $status->st_session?></td>
                                  
                                </tr>

                              </tbody>
                            </table>
                            <!-- end user projects -->

                          </div>
                          <div role="tabpanel" class="tab-pane fade" id="tab_profile3" aria-labelledby="profile-tab">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                            consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                            proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              
          </div>
        </div>
        <!-- /my profile -->
      </div>
      
        <!-- Subject enroll -->
      <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
                          
         <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Subject Enroll</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
                          <img class="img-responsive avatar-view" src="../public/images/user.png" alt="Avatar" title="<?php echo $status->st_fullname?>">
                        </div>
                      </div>
                      <h3><?php echo $status->st_fullname?></h3>

                      <ul class="list-unstyled user_data">
                        <li>
                          <i class="fa fa-envelope" aria-hidden="true"></i>
                            <?php echo $status->st_email?>
                        </li>

                        <li>
                          <i class="fa fa-briefcase user-profile-icon"></i> <?php echo $status->class_name?>
                        </li>

                        <li class="m-top-xs">
                          <i class="fa fa-external-link user-profile-icon"></i>
                          <a href="#" target="_blank">superior.edu.pk</a>
                        </li>
                      </ul>
        

                      
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12"> 
                        <div id="myTabContent" class="tab-content">
                           <table class="data table table-striped no-margin">
                              <thead>
                                <tr>
                                  <th>#</th>
                                  <th>Subject Name</th>
                                  <th>Teacher Name</th>
                                  <th>TCR</th>
                                  <th>Semester</th>
                                </tr>
                              </thead>
                              <tbody>
                                  <?php $student->getStudentInfoSubjectEnroll($arg,$db);?>
                              </tbody>
                            </table>
                          </div>
                          
                       
                    </div>
                  </div>
                </div>
              
          </div>
        </div>                   
                       
     </div>


  <div role="tabpanel" class="tab-pane fade" id="tab_content3" aria-labelledby="profile-tab">

    <!-- time table -->
       
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Time Table</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
                          <img class="img-responsive avatar-view" src="../public/images/user.png" alt="Avatar" title="<?php echo $status->st_fullname?>">
                        </div>
                      </div>
                      <h3><?php echo $status->st_fullname?></h3>

                      <ul class="list-unstyled user_data">
                        <li>
                          <i class="fa fa-envelope" aria-hidden="true"></i>
                            <?php echo $status->st_email?>
                        </li>

                        <li>
                          <i class="fa fa-briefcase user-profile-icon"></i> <?php echo $status->class_name?>
                        </li>

                        <li class="m-top-xs">
                          <i class="fa fa-external-link user-profile-icon"></i>
                          <a href="#" target="_blank">superior.edu.pk</a>
                        </li>
                      </ul>

        

                      
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12">

                      <table class="data table table-striped no-margin">
                              <thead>
                                <tr>
                                  <th>#</th>
                                  <th>Subject Name</th>
                                  <th>Teacher Name</th>
                                  <th>Days</th>
                                   <th>Time</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php $student->getStudentInfoTimeTables($arg,$section,$db);?>
                                
                              </tbody>
                            </table>
                          </div>
                  </div>
                </div>
              
          </div>
        </div>
        <!-- /time table -->


    </div>
  <!--  Attendance  -->   
    <div role="tabpanel" class="tab-pane fade" id="tab_content4" aria-labelledby="profile-tab">
         <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Attendance</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
                        
                          <img class="img-responsive avatar-view" src="../public/images/user.png" alt="Avatar" title="<?php echo $status->st_fullname?>">
                        </div>
                      </div>
                      <h3><?php echo $status->st_fullname?></h3>

                      <ul class="list-unstyled user_data">
                        <li>
                          <i class="fa fa-envelope" aria-hidden="true"></i>
                            <?php echo $status->st_email?>
                        </li>

                        <li>
                          <i class="fa fa-briefcase user-profile-icon"></i> <?php echo $status->class_name?>
                        </li>

                        <li class="m-top-xs">
                          <i class="fa fa-external-link user-profile-icon"></i>
                          <a href="#" target="_blank">superior.edu.pk</a>
                        </li>
                      </ul>  
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                     <div id="myTabContent" class="tab-content">
                          <table class="data table table-striped no-margin">
                              <thead>
                                <tr>
                                  <th>#</th>
                                  <th>Subject Title</th>
                                  <th>Teacher Name</th>
                                  <th>NOL</th>
                                  <th>NOP</th>
                                  <th>NOA</th>
                                  <th>ATT %</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php $student->getStudentInfoAttendance($session,$db) ?>
                              </tbody>
                            </table>
                          </div>
                 </div>      
               </div>
             </div>                   
          </div>
           </div>                   
          </div>
              
                        
  <div role="tabpanel" class="tab-pane fade" id="tab_content5" aria-labelledby="profile-tab">
                 
    <!-- assignment -->
          <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Assignment Section</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
                          <img class="img-responsive avatar-view" src="../public/images/user.png" alt="Avatar" title="<?php echo $status->st_fullname?>">
                        </div>
                      </div>
                      <h3><?php echo $status->st_fullname?></h3>

                      <ul class="list-unstyled user_data">
                        <li>
                          <i class="fa fa-envelope" aria-hidden="true"></i>
                            <?php echo $status->st_email?>
                        </li>

                        <li>
                          <i class="fa fa-briefcase user-profile-icon"></i> <?php echo $status->class_name?>
                        </li>

                        <li class="m-top-xs">
                          <i class="fa fa-external-link user-profile-icon"></i>
                          <a href="#" target="_blank">superior.edu.pk</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                           <table class="data table table-striped no-margin">
                              <thead>
                                <tr>
                                  <th>#</th>
                                  <th>Subject Title</th>
                                  <th>Teacher Name</th>
                                  <th>Submission Date</th>
                                  <th>Assignment</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php $student->getStudentInfoAssignment($arg,$section,$db); ?>
                              </tbody>
                            </table>
                            <!-- end user projects -->

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- /assignment -->                         
               </div>                     
                        
   <div role="tabpanel" class="tab-pane fade" id="tab_content6" aria-labelledby="profile-tab">
       

    <!-- fee details -->
          <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Fee Ststus</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
                          <img class="img-responsive avatar-view" src="../public/images/user.png" alt="Avatar" title="<?php echo $status->st_fullname?>">
                        </div>
                      </div>
                      <h3><?php echo $status->st_fullname?></h3>

                      <ul class="list-unstyled user_data">
                        <li>
                          <i class="fa fa-envelope" aria-hidden="true"></i>
                            <?php echo $status->st_email?>
                        </li>

                        <li>
                          <i class="fa fa-briefcase user-profile-icon"></i> <?php echo $status->class_name?>
                        </li>

                        <li class="m-top-xs">
                          <i class="fa fa-external-link user-profile-icon"></i>
                          <a href="#" target="_blank">superior.edu.pk</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                       <table class="data table table-striped no-margin">
                              <thead>
                                <tr>
                                  <th>Semester</th>
                                  <th>Fee</th>
                                  <th>Status</th>
                                </tr>
                              </thead>
                              <tbody>
                                 <?php $student->getStudentInfoFeeDetails($session,$db); ?>
                              </tbody>
                            </table>
                            <!-- end user projects -->

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- /fee detail -->                         
               </div>                     
                

<div role="tabpanel" class="tab-pane fade" id="tab_content7" aria-labelledby="profile-tab">
       

    <!-- datesheet-->
          <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Datesheet</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
                          <!-- Current avatar -->
                          <img class="img-responsive avatar-view" src="../public/images/user.png" alt="Avatar" title="<?php echo $status->st_fullname?>">
                        </div>
                      </div>
                      <h3><?php echo $status->st_fullname?></h3>

                      <ul class="list-unstyled user_data">
                        <li>
                          <i class="fa fa-envelope" aria-hidden="true"></i>
                            <?php echo $status->st_email?>
                        </li>

                        <li>
                          <i class="fa fa-briefcase user-profile-icon"></i> <?php echo $status->class_name?>
                        </li>

                        <li class="m-top-xs">
                          <i class="fa fa-external-link user-profile-icon"></i>
                          <a href="#" target="_blank">superior.edu.pk</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                       <table class="data table table-striped no-margin">
                              <thead>
                                <tr>
                                  <th>#</th>
                                  <th>Subject</th>
                                  <th>Date</th>
                                  <th>Time</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php $student->getStudentInfoDateSheet($arg,$db); ?>
                              </tbody>
                            </table>
                            <!-- end user projects -->

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- /datesheet -->                         
               </div>                     
                
                      
        <div role="tabpanel" class="tab-pane fade" id="tab_content9" aria-labelledby="profile-tab">
       

    <!-- datesheet -->
          <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Notices </h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
                          <img class="img-responsive avatar-view" src="../public/images/user.png" alt="Avatar" title="<?php echo $status->st_fullname?>">
                        </div>
                      </div>
                      <h3><?php echo $status->st_fullname?></h3>

                      <ul class="list-unstyled user_data">
                        <li>
                          <i class="fa fa-envelope" aria-hidden="true"></i>
                            <?php echo $status->st_email?>
                        </li>

                        <li>
                          <i class="fa fa-briefcase user-profile-icon"></i> <?php echo $status->class_name?>
                        </li>

                        <li class="m-top-xs">
                          <i class="fa fa-external-link user-profile-icon"></i>
                          <a href="#" target="_blank">superior.edu.pk</a>
                        </li>
                      </ul>
                    </div>
                   
                    <div class="col-md-9 col-sm-9 col-xs-12">
                       <h1>University Important Notices</h1>
                       <?php $admin->getUniversityNoyics($db); ?>

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- /datesheet detail -->                         
               </div>                     
      

<div role="tabpanel" class="tab-pane fade" id="tab_content8" aria-labelledby="profile-tab">
       

    <!-- academy details -->
          <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Academics Report </h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
                          <img class="img-responsive avatar-view" src="../public/images/user.png" alt="Avatar" title="<?php echo $status->st_fullname?>">
                        </div>
                      </div>
                      <h3><?php echo $status->st_fullname?></h3>

                      <ul class="list-unstyled user_data">
                        <li>
                          <i class="fa fa-envelope" aria-hidden="true"></i>
                            <?php echo $status->st_email?>
                        </li>

                        <li>
                          <i class="fa fa-briefcase user-profile-icon"></i> <?php echo $status->class_name?>
                        </li>

                        <li class="m-top-xs">
                          <i class="fa fa-external-link user-profile-icon"></i>
                          <a href="#" target="_blank">superior.edu.pk</a>
                        </li>
                      </ul>                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                       <table class="data table table-striped no-margin">
                              <thead>
                                <caption>4th Semester</caption>
                                <tr>
                                  <th>#</th>
                                  <th>Subject Title</th>
                                  <th>Instructor</th>
                                  <th>Mid Term</th>
                                  <th>Final Term</th>
                                  <th>Total Marks</th>
                                  <th>Max Marks</th>
                                  <th>Grade</th>
                                  
                                </tr>
                              </thead>
                              <tbody>
                                <?php $student->getStudentInfoAcademicDetails($session,$db); ?>
                               
                              </tbody>
                            </table>
                            <!-- end user projects -->

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- /academy detail -->                         
               </div>                     
                                       


                        
                        
                      </div>
                    </div>

                  </div>
                </div>
              </div>
      
          <div class="clearfix"></div>
        </div>
        <!-- /page content -->

        
      </div>
    </div>

    <div id="custom_notifications" class="custom-notifications dsp_none">
      <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
      </ul>
      <div class="clearfix"></div>
      <div id="notif-group" class="tabbed_notifications"></div>
    </div>



<!-- footer content -->
       <?php require_once('footer.php');?>
        <!-- /footer content --><!-- jQuery -->
    
<!-- JavaScript files --> 
  <?php require_once('js.php');?>
 <!-- JavaScript files-->



    
 