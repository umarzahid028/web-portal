<?php  
class Student{

	public function login($arg, $db){
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$status = $this->validate_sanitize_login($arg);
			if (is_array($status)) {
				$status = $this->authenticate($status, $db);
				return $status;
				
			}
			else{
				return "error";
			}
		}
		else{
			return $status;
		}
	}

	protected function input_recieved($arg){
		if (is_array($arg)) {
		foreach ($arg AS $input) {
			if ($input == "" OR $input == NULL) {
				return "input_missing";
			}
		}
	}
	return true;
	}

	protected function validate_sanitize_login($arg){
		$user_id  = filter_var($arg['user-id'], FILTER_SANITIZE_STRING);
		$password = filter_var($arg['password'], FILTER_SANITIZE_STRING);

		return array('user-id' =>$user_id, 'password' =>$password);
	}

	private function authenticate($arg, $db){

		$user_id  = $arg['user-id'];
		$password = $arg['password'];
		$duration =5000;


		$sql = "SELECT `st_id`,`st_fullname`,`st_registation_no`,`st_email`,`st_password` FROM `student_info` WHERE `st_registation_no`=?";
		$stmt = $db->prepare($sql);

		if ( is_object($stmt) ) {
			$stmt->bindParam(1,$user_id, PDO::PARAM_STR);
			$stmt->execute();

			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
				if ( password_verify( $password, $row->st_password )) {
					
					$_SESSION['logged_in']=[

						'id'             =>$row->st_id,
						'fullname'       =>$row->st_fullname,
						'email'          =>$row->st_email,
						'registation_no' =>$row->st_registation_no,
						'account_type'   =>'student',
						'start-time'     =>time(),
						'duration'       =>$duration
					];
					session_regenerate_id(true);
					return 'success';
				}
				return 'error';
			}
		}
	}

	public function changePassword($arg, $db){
		/*
		* make sure to grab all form data
		* sanitization all input
		* check if the old password is valid
		* new password and confirm new password are metched
		*/
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$status = $this->validate_sanitize_change_password($arg);
			if (is_array($status)) {
				$status = $this->passwordExistsValidate($arg, $db);
				if ($status === true) {
					$status = $this->update_password($arg, $db);
					return $status;
				}
				return $status;
			}
			else{
				return "error";
			}
		}
		else{
			return $status;
		}
	}

	protected function validate_sanitize_change_password($arg){
		$old_password = filter_var($arg['old-password'], FILTER_SANITIZE_STRING);
		$n_password   = filter_var($arg['npassword'], FILTER_SANITIZE_STRING);
		$c_password   = filter_var($arg['cpassword'], FILTER_SANITIZE_STRING);

		return array('old-password' =>$old_password , 'npassword' =>$n_password,'cpassword' =>$c_password);
	}
	private function passwordExistsValidate($arg, $db){

		$id = $arg['id'];
		$old_password = $arg['old-password'];
		
		$sql = "SELECT `st_id`,`st_password` FROM `student_info` WHERE `st_id`=?";
		$stmt = $db->prepare($sql);

		if ( is_object($stmt) ) {
			$stmt->bindParam(1, $id, PDO::PARAM_INT);
			$stmt->execute();

			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
				if ( password_verify( $old_password, $row->st_password )) {
					
					if ($arg['npassword'] !== $arg['cpassword'] ) {
					
						return "mismatch_password";
					}
				    return true;
				}
				return 'old_password_wrong';
			}	
		}
	}

	private function update_password($arg, $db){
		$sql = "UPDATE `student_info` SET `st_password`=? WHERE `st_id`=?";
		$stmt = $db->prepare($sql);

		if (is_object($stmt)) {
			$hash = password_hash($arg['cpassword'], PASSWORD_DEFAULT);
			$id = $arg['id'];

			$stmt->bindParam(1,$hash, PDO::PARAM_STR);
			$stmt->bindParam(2,$id, PDO::PARAM_STR);
			$stmt->execute();

			if ($stmt->rowCount() == 1) {
				return 'success';
			}
			return 'error';
		}
	}


	protected function sendMail($arg){
		// Create the Transport
		$transport = (new Swift_SmtpTransport('smtp.mailtrap.io', 2525))
		  ->setUsername('29be8018692e82')
		  ->setPassword('45210bbdb89c6a')
		;

		// Create the Mailer using your created Transport
		$mailer = new Swift_Mailer($transport);

		// Create a message
		$message = (new Swift_Message('Password Recovery Request !'))
		  ->setFrom(['noreply@superioruniversity.com' => 'Administrator of Superior University Faisalabad Campus'])
		  ->setTo([$arg->st_email])
		  ->setBody(passwordRecoverEmailMessageBody($arg), 'text/html')
		  ;

		// Send the message
		$result = $mailer->send($message);

		if ($result) {
			return true;
		}
		else{
			return false;
		}
	}

	public function mailPasswordLink($arg, $db){

		/*
		* make sure to grab all form data
		* check the email exists in database
		*/

		$status = $this->input_recieved($arg);
		if ($status === true) {
			$status = $this->validate_sanitize_email($arg);
			if ($status === true) {
				$status = $this->emailExists($arg,$db);
				if ($status === true) {
					return "success";
				}
				else{
					return $status;
				}
			}
			else{
				return $status;
			}
		}
		else{
			return $status;
		}
	}

	protected function validate_sanitize_email($arg){
		$email = filter_var($arg['email'], FILTER_SANITIZE_EMAIL);
		$email = filter_var($email, FILTER_VALIDATE_EMAIL);
		if (!$email) {
			return "wrong_formet";
		}
		return true;
	}
	private function emailExists($arg,$db){

		$sql ="SELECT * FROM `student_info` WHERE `st_email`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg['email'], PDO::PARAM_STR);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
				$status=$this->sendMail($row);

				return true;
			}
			return "no_found";
		}
	}


	public function updateResetPassword($arg, $db){
		/*
		* All fields data received
		* new password and confirm password macthed
		* user id is valid
		* varification code is valid
		*/
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$status = $this->passwordMatchedOrNot($arg);
			if ($status === true) {
				$status = $this->idExists($arg,$db);
				if ($status === true) {
					$status = $this->codeExists($arg,$db);
					if ($status === true) {
						$status = $this->updatePassword($arg,$db);
						if ($status === true) {
							
							return $status = "success";
						}
						else{
							return "error";
						}
					}
					else{
						$this->regenerteCode($arg,$db);
						$row = $this->getStudentDtetails($arg,$db);
						$this->sendMail($row);
						return $status;
					}
				}
				else{
					return $status;
				}
			}
			else{
				return $status;
			}
		}
		else{
			return $status;
		}
	}                
	protected function passwordMatchedOrNot($arg){
		if ($arg['npassword'] !== $arg['cpassword'] ) {
					
			return "mismatch_password";
		}
		return true;
	}

	private function idExists($arg,$db){

		$sql ="SELECT `st_id` FROM `student_info` WHERE `st_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
				if ($arg['id'] === $row->st_id) {
					return true;
				}
				
			}
			return "incorrect_id";
		}
	}
	private function codeExists($arg,$db){

		$sql ="SELECT `st_verification_code` FROM `student_info` WHERE `st_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
			
				if ($arg['code'] === $row->st_verification_code) {

					return true;
				}
				
			}
			return "incorrect_code";
		} 
	}
	private function regenerteCode($arg,$db){

		$sql ="UPDATE `student_info` SET `st_verification_code`=? WHERE `st_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$code = generateCode();
			$stmt->bindParam(1, $code, PDO::PARAM_STR);
			$stmt->bindParam(2, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($stmt->rowCount()) {

				return true;
			}
			return "errror";
		}
	}

	private function getStudentDtetails($arg,$db){

		$sql ="SELECT * FROM `student_info` WHERE `st_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$code = generateCode();
			$stmt->bindParam(1, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {

				return $row;
			}
			return false;
		}
	}

	private function updatePassword($arg,$db){

		$sql ="UPDATE `student_info` SET `st_password`=?, `st_verification_code`=? WHERE `st_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$hash = password_hash($arg['cpassword'], PASSWORD_DEFAULT);
			$code = generateCode();

			$stmt->bindParam(1, $hash, PDO::PARAM_STR);
			$stmt->bindParam(2, $code, PDO::PARAM_STR);
			$stmt->bindParam(3, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($stmt->rowCount()) {

				return true;
			}
			return "error";
		}
	}

	public function getStudentinfo($arg,$db){
		// get information front end page student portal

		$sql ="SELECT * FROM `student_info` JOIN `classes` JOIN `department` ON `student_info`.`st_class_id` = `classes`.`class_id` AND `student_info`.`st_department_id` = `department`.`department_id` WHERE `st_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg, PDO::PARAM_INT);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {

				return $row;
			}
			return false;
		}
	}
	
	public function getStudentInfoSubjectEnroll($arg,$db){
		// get information subject enroll

		$sql ="SELECT `subject`.`subject_name`,`subject`.`subject_tcr`,`subject`.`semester`,`subject`.`semester`,`classes`.`class_name`,`instructor`.`instructor_name` FROM `subject` JOIN `classes` JOIN `instructor` ON `subject`.`class_id` = `classes`.`class_id` AND `subject`.`instructor_id` = `instructor`.`instructor_id` WHERE `subject`.`class_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg, PDO::PARAM_INT);
			$stmt->execute();
			$i=0;
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				$i++;
				echo "<tr>
	                    <td>$i</td>
	                    <td>$row->subject_name</td>
	                    <td>$row->instructor_name</td>
	                    <td>$row->subject_tcr</td>
	                    <td>$row->semester</td>              
	                  </tr>
	                  
	                  ";		
			}		
		}
	}

	public function getStudentInfoTimeTables($arg,$section,$db){
		// get information time table

		$sql ="SELECT `time_table`.`time`,`time_table`.`section`,`time_table`.`days`,`subject`.`subject_name`,`instructor`.`instructor_name` FROM `time_table` JOIN `subject` JOIN `instructor` ON `time_table`.`subject_id`= `subject`.`subject_id` AND `time_table`.`instructor_id`=`instructor`.`instructor_id` WHERE `time_table`.`class_id`=? AND `time_table`.`section`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg, PDO::PARAM_INT);
			$stmt->bindParam(2, $section, PDO::PARAM_STR);
			$stmt->execute();
			$i=0;
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				$i++;
				echo "<tr>
	                    <td>$i</td>
	                    <td>$row->subject_name</td>
	                    <td>$row->instructor_name</td>
	                    <td>$row->days</td>
	                    <td>$row->time</td>              
	                  </tr>
	                  
	                  ";		
			}		
		}
	}

	public function getStudentInfoAttendance($arg,$db){
		// get information attenance

		$sql ="SELECT `attendance`.`section`,`attendance`.`nol`,`attendance`.`nop`,`attendance`.`noa`,`subject`.`subject_name`,`instructor`.`instructor_name` FROM `attendance` JOIN `subject` JOIN `instructor` ON `attendance`.`subject_id`=`subject`.`subject_id` AND `attendance`.`instructor_id`=`instructor`.`instructor_id` WHERE `attendance`.`student_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg, PDO::PARAM_INT);
			$stmt->execute();
			$i=0;
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				$i++;
				$percentage = $row->nop*100/30;
				$percentage = sprintf('%.2f',$percentage);
				echo "<tr>
	                    <td>$i</td>
	                    <td>$row->subject_name</td>
	                    <td>$row->instructor_name</td>
	                    <td>$row->nol</td>
	                    <td>$row->nop</td>
	                    <td>$row->noa</td> 
	                    <td>$percentage</td>             
	                  </tr>
	                  
	                  ";		
			}		
		}
	}

	public function getStudentInfoAssignment($arg,$section,$db){
		// get information Assignment

		$sql ="SELECT `assignment`.`submission_date`,`assignment`.`section`,`assignment`.`assignment_url`,`subject`.`subject_name`,`instructor`.`instructor_name` FROM `assignment` JOIN `subject` JOIN `instructor` ON `assignment`.`subject_id`=`subject`.`subject_id` AND `assignment`.`instructor_id`=`instructor`.`instructor_id` WHERE `assignment`.`class_id`=? AND `assignment`.`section`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg, PDO::PARAM_INT);
			$stmt->bindParam(2, $section, PDO::PARAM_STR);
			$stmt->execute();
			$i=0;
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				$i++;

				echo "<tr>
	                    <td>$i</td>
	                    <td>$row->subject_name</td>
	                    <td>$row->instructor_name</td>
	                    <td>$row->submission_date</td>
	                    <td><a href='$row->assignment_url'>Click to Download</a></td>             
	                  </tr>
	                  
	                  ";		
			}		
		}
	}

	public function getStudentInfoFeeDetails($session,$db){
		// get information fee details

		$sql ="SELECT `fee_details`.`fee`,`fee_details`.`semester`,`fee_details`.`status`,`student_info`.`st_fullname` FROM `fee_details`	JOIN `student_info` ON `fee_details`.`student_id`=`student_info`.`st_id` WHERE `fee_details`.`student_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $session, PDO::PARAM_INT);
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {

				echo "<tr>
	                    <td>$row->semester</td>
	                    <td>$row->fee</td>
	                    <td>$row->status</td>            
	                  </tr> ";		
			}		
		}
	}
	public function getStudentInfoDateSheet($class_id,$db){
		// get information datesheet

		$sql ="SELECT * FROM `date_sheet` JOIN `subject` ON `date_sheet`.`subject_id`=`subject`.`subject_id` WHERE `date_sheet`.`class_id`=? AND `date_sheet`.`semester`= (SELECT MAX(`academic_details`.`semester`) FROM `academic_details`)";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $class_id, PDO::PARAM_INT);
			$stmt->execute();
			$i=0;
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				$i++;
				echo "<tr>
						<td>$i</td>
	                    <td>$row->subject_name</td>
	                    <td>$row->date</td>
	                    <td>$row->time</td>            
	                  </tr> ";		
			}		
		}
	}
	public function getStudentInfoAcademicDetails($session,$db){
		// get information academic details

		$sql ="SELECT `academic_details`.`semester`, `academic_details`.`mid`, `academic_details`.`final`, `academic_details`.`total`, `academic_details`.`max_marks`, `academic_details`.`grade`,`subject`.`subject_name`,`instructor`.`instructor_name` FROM `academic_details`JOIN `subject` JOIN `instructor` ON `academic_details`.`subject_id`=`subject`.`subject_id` AND `academic_details`.`instructor_id`=`instructor`.`instructor_id` WHERE `academic_details`.`student_id`=? AND `academic_details`.`semester` = (SELECT MAX(`academic_details`.`semester`) FROM `academic_details`)";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $session, PDO::PARAM_INT);
			$stmt->execute();
			$i=0;
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				$i++;

				echo "<tr>
	                    <td>$i</td>
	                    <td>$row->subject_name</td>
	                    <td>$row->instructor_name</td>
	                    <td>$row->mid</td>
	                    <td>$row->final</td>
	                    <td>$row->total</td>
	                    <td>$row->max_marks</td> 
	                    <td>$row->grade</td>             
	                  </tr>";

			}			
		}
	}

	public function instructorMessages($class_id,$section,$db){
		// get instructor messages

		$sql ="SELECT `instructor_messages`.`title`, `instructor_messages`.`data_time`, `instructor_messages`.`messages`,`instructor`.`instructor_name` FROM `instructor_messages` JOIN `instructor` JOIN `classes` ON `instructor_messages`.`instructor_id`=`instructor`.`instructor_id` AND `instructor_messages`.`class_id`=`classes`.`class_id` WHERE `instructor_messages`.`class_id`=? AND `instructor_messages`.`section`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $class_id, PDO::PARAM_INT);
			$stmt->bindParam(2, $section, PDO::PARAM_STR);
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {

				echo "
					<ul class='list-unstyled timeline'>
                    	<li>
							<div class='block'>
		                        <div class='tags'>
		                          <a href='' class='tag'>
		                            <span>$row->instructor_name</span>
		                          </a>
		                        </div>
		                        <div class='block_content'>
		                          <h2 class='title'>
		                              <a>$row->title</a>
		                            </h2>
		                          <div class='byline'>
		                            <span>$row->data_time</span> by <a>$row->instructor_name</a>
		                          </div>
		                          <p class='excerpt'>$row->messages</p>
		                        </div>
		                    </div>
		                </li>
                	</ul>";
			}			
		}
	}

	public function getStudentInfoAcademicDetailsSemessterWise($session,$db){
		// get information academic details semester wise

		$sql ="SELECT SUM(`total`),SUM(`max_marks`),SUM(`gpa`), `semester` AS abc FROM `academic_details` WHERE `student_id`=? GROUP BY abc";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $session, PDO::PARAM_INT);
			$stmt->execute();
			$i=0;
			while ( $row = $stmt->fetch(PDO::FETCH_ASSOC)) {
				$i++;
				
				$gpa =sprintf('%.2f',$row['SUM(`gpa`)'] /4);
				$cgpa =sprintf('%.2f',$gpa / $i );

				echo "<tr>
	                    <td>".$row['abc']."</td>
	                    <td>".$row['SUM(`total`)']."</td>
	                    <td>".$row['SUM(`max_marks`)']."</td>
	                    <td>$gpa</td>
	                    <td>$cgpa</td>
	                                 
	                  </tr>";

			}			
		}
	}






// Student class end
}


$student = new Student;