<?php 
/**
* 
*/
class Admin extends Student {

	public function login($arg, $db){
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$status = $this->validate_sanitize_login($arg);
			if (is_array($status)) {
				$status = $this->adminAuthenticate($status, $db);
				return $status;
				
			}
			else{
				return "error";
			}
		}
		else{
			return $status;
		}
	}
	private function adminAuthenticate($arg, $db){

		$user_id  = $arg['user-id'];
		$password = $arg['password'];
		$duration =5000;


		$sql = "SELECT `id`,`fullname`,`email`,`password` FROM `admin` WHERE `email`=?";
		$stmt = $db->prepare($sql);

		if ( is_object($stmt) ) {
			$stmt->bindParam(1,$user_id, PDO::PARAM_STR);
			$stmt->execute();

			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
				if ( password_verify( $password, $row->password )) {
					
					$_SESSION['logged_in']=[

						'id'             =>$row->id,
						'fullname'       =>$row->fullname,
						'email'          =>$row->email,
						'account_type'   =>'admin',
						'start-time'     =>time(),
						'duration'       =>$duration
					];
					session_regenerate_id(true);
					return 'success';
				}
				return 'error';
			}
		}
	}


	public function adminChangePassword($arg, $db){
		/*
		* make sure to grab all form data
		* sanitization all input
		* check if the old password is valid
		* new password and confirm new password are metched
		*/
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$status = $this->validate_sanitize_change_password($arg);
			if (is_array($status)) {
				$status = $this->adminPasswordExistsValidate($arg, $db);
				if ($status === true) {
					$status = $this->adminUpdatePassword($arg, $db);
					return $status;
				}
				return $status;
			}
			else{
				return "error";
			}
		}
		else{
			return $status;
		}
	}
	private function adminPasswordExistsValidate($arg, $db){

		$id = $arg['id'];
		$old_password = $arg['old-password'];
		
		$sql = "SELECT `id`,`password` FROM `admin` WHERE `id`=?";
		$stmt = $db->prepare($sql);

		if ( is_object($stmt) ) {
			$stmt->bindParam(1, $id, PDO::PARAM_INT);
			$stmt->execute();

			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
				if ( password_verify( $old_password, $row->password )) {
					
					if ($arg['npassword'] !== $arg['cpassword'] ) {
					
						return "mismatch_password";
					}
				    return true;
				}
				return 'old_password_wrong';
			}	
		}
	}

	private function adminUpdatePassword($arg, $db){
		$sql = "UPDATE `admin` SET `password`=? WHERE `id`=?";
		$stmt = $db->prepare($sql);

		if (is_object($stmt)) {
			$hash = password_hash($arg['cpassword'], PASSWORD_DEFAULT);
			$id = $arg['id'];

			$stmt->bindParam(1,$hash, PDO::PARAM_STR);
			$stmt->bindParam(2,$id, PDO::PARAM_STR);
			$stmt->execute();

			if ($stmt->rowCount() == 1) {
				return 'success';
			}
			return 'error';
		}
	}
	public function adminMailPasswordLink($arg, $db){

		/*
		* make sure to grab all form data
		* check the email exists in database
		*/

		$status = $this->input_recieved($arg);
		if ($status === true) {
			$status = $this->validate_sanitize_email($arg);
			if ($status === true) {
				$status = $this->adminEmailExists($arg,$db);
				if ($status === true) {
					return "success";
				}
				else{
					return $status;
				}
			}
			else{
				return $status;
			}
		}
		else{
			return $status;
		}
	}

	private function adminEmailExists($arg,$db){

		$sql ="SELECT * FROM `admin` WHERE `email`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg['email'], PDO::PARAM_STR);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
				$status=$this->adminSendMail($row);

				return true;
			}
			return "no_found";
		}
	}

	public function adminUpdateResetPassword($arg, $db){
		/*
		* All fields data received
		* new password and confirm password macthed
		* user id is valid
		* varification code is valid
		*/
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$status = $this->passwordMatchedOrNot($arg);
			if ($status === true) {
				$status = $this->adminIdExists($arg,$db);
				if ($status === true) {
					$status = $this->adminCodeExists($arg,$db);
					if ($status === true) {
						$status = $this->adminResetUpdatePassword($arg,$db);
						if ($status === true) {
							
							return $status = "success";
						}
						else{
							return "error";
						}
					}
					else{
						$this->adminRegenerteCode($arg,$db);
						$row = $this->getadminDtetails($arg,$db);
						$this->adminSendMail($row);
						return $status;
					}
				}
				else{
					return $status;
				}
			}
			else{
				return $status;
			}
		}
		else{
			return $status;
		}
	}                


	private function adminIdExists($arg,$db){

		$sql ="SELECT `id` FROM `admin` WHERE `id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
				if ($arg['id'] === $row->id) {
					return true;
				}
				
			}
			return "incorrect_id";
		}
	}
	private function adminCodeExists($arg,$db){

		$sql ="SELECT `verification_code` FROM `admin` WHERE `id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
			
				if ($arg['code'] === $row->verification_code ) {

					return true;
				}
				
			}
			return "incorrect_code";
		} 
	}

	private function adminRegenerteCode($arg,$db){

		$sql ="UPDATE `admin` SET `verification_code`=? WHERE `id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$code = generateCode();
			$stmt->bindParam(1, $code, PDO::PARAM_STR);
			$stmt->bindParam(2, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($stmt->rowCount()) {

				return true;
			}
			return "errror";
		}
	}

	private function getadminDtetails($arg,$db){

		$sql ="SELECT * FROM `admin` WHERE `id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$code = generateCode();
			$stmt->bindParam(1, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {

				return $row;
			}
			return false;
		}
	}

	private function adminResetUpdatePassword($arg,$db){

		$sql ="UPDATE `admin` SET `password`=?, `verification_code`=? WHERE `id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$hash = password_hash($arg['cpassword'], PASSWORD_DEFAULT);
			$code = generateCode();

			$stmt->bindParam(1, $hash, PDO::PARAM_STR);
			$stmt->bindParam(2, $code, PDO::PARAM_STR);
			$stmt->bindParam(3, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($stmt->rowCount()) {

				return true;
			}
			return "error";
		}
	}
	protected function adminSendMail($arg){
		// Create the Transport
		$transport = (new Swift_SmtpTransport('smtp.mailtrap.io', 2525))
		  ->setUsername('29be8018692e82')
		  ->setPassword('45210bbdb89c6a')
		;

		// Create the Mailer using your created Transport
		$mailer = new Swift_Mailer($transport);

		// Create a message
		$message = (new Swift_Message('Password Recovery Request !'))
		  ->setFrom(['noreply@superioruniversity.com' => 'Our System of Superior University Faisalabad Campus'])
		  ->setTo([$arg->email])
		  ->setBody(adminPasswordRecoverEmailMessageBody($arg), 'text/html')
		  ;

		// Send the message
		$result = $mailer->send($message);

		if ($result) {
			return true;
		}
		else{
			return false;
		}
	}


	public function getadminInfo($arg,$db){
		// getter-> information instructor

		$sql ="SELECT * FROM `admin` WHERE `id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg, PDO::PARAM_INT);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {

				return $row;
			}
			return false;
		}
	}

	public function getDepartmentId($db){
		// getter 
		$sql ="SELECT `department_id`, `department_name` FROM `department`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				
				echo "<option value='$row->department_id'>$row->department_name</option>";		
			}		
		}
	}
	public function getInstructor($db){
		// getter 
		$sql ="SELECT `instructor_id`, `instructor_name` FROM `instructor`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				
				echo "<option value='$row->instructor_id'>$row->instructor_name</option>";		
			}		
		}
	}
	public function getStudentId($db){
		// getter 
		$sql ="SELECT `st_id`, `st_fullname`, `st_roll_no` FROM `student_info`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				
				echo "<option value='$row->st_id'>".$row->st_fullname ."-".$row->st_roll_no."</option>";		
			}		
		}
	}

	public function getClasses($db){
		// getter 
		$sql ="SELECT `class_id`, `class_name` FROM `classes`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				
				echo "<option value='$row->class_id'>$row->class_name</option>";		
			}		
		}
	}
	public function getSubjects($db){
		// getter 
		$sql ="SELECT `subject_id`, `subject_name` FROM `subject`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				
				echo "<option value='$row->subject_id'>$row->subject_name</option>";		
			}		
		}
	}

	public function setDepartment($arg,$db){

		$status = $this->input_recieved($arg);
		if ($status === true) {
			$sql ="INSERT INTO `department`(`department_name`) VALUES (?)";
			$stmt = $db->prepare($sql);
			if (is_object($stmt)) {
				$stmt->bindParam(1, $arg['name'], PDO::PARAM_STR);

				$stmt->execute();
				if ($stmt->rowCount()) {

					return "success";
				}
				return "error";
			}

		}
		return "input_missing";
		
	}

	public function getDepartment($db){

		$sql ="SELECT * FROM `department`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				

				echo "<tr style='background:#000; color:#FFF;'>
	                    <td>$row->department_id</td>
	                    <td>$row->department_name</td>               
	                  </tr>";
			}		
			
		}
	}

	public function setClasses($arg,$db){

		$status = $this->input_recieved($arg);
		if ($status === true) {
			$sql ="INSERT INTO `classes`(`class_name`, `department_id`) VALUES (?,?)";
			$stmt = $db->prepare($sql);
			if (is_object($stmt)) {
				$stmt->bindParam(1, $arg['class-name'], PDO::PARAM_STR);
				$stmt->bindParam(2, $arg['department-id'], PDO::PARAM_INT);

				$stmt->execute();
				if ($stmt->rowCount()) {

					return "success";
				}
				return "error";
			}

		}
		return "input_missing";
		
	}

	public function getClassesInfo($db){

		$sql ="SELECT * FROM `classes` JOIN `department` ON `classes`.`department_id`=`department`.`department_id`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				

				echo "<tr style='background:#000; color:#FFF;'>
	                    <td>$row->class_name</td>
	                    <td>$row->department_name</td>               
	                  </tr>";
			}		
			
		}
	}

	public function setSubjects($arg,$db){
		
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$sql ="INSERT INTO `subject`(`class_id`, `subject_name`, `subject_tcr`, `semester`, `instructor_id`) VALUES (?,?,?,?,?) ";
			$stmt = $db->prepare($sql);
			if (is_object($stmt)) {
				$stmt->bindParam(1, $arg['class-id'], PDO::PARAM_INT);
				$stmt->bindParam(2, $arg['subject-name'], PDO::PARAM_STR);
				$stmt->bindParam(3, $arg['subject-tcr'], PDO::PARAM_INT);
				$stmt->bindParam(4, $arg['semester'], PDO::PARAM_STR);
				$stmt->bindParam(5, $arg['instructor-id'], PDO::PARAM_INT);

				$stmt->execute();
				if ($stmt->rowCount()) {

					return "success";
				}
				return "error";
			}

		}
		return "input_missing";
		
	}

	public function getSubjectInfo($db){

		$sql ="SELECT `subject`.`class_id`, `subject`.`subject_name`, `subject`.`subject_tcr`, `subject`.`semester`, `subject`.`instructor_id`,`classes`.`class_name`,`instructor`.`instructor_name` FROM `subject` JOIN `classes` JOIN `instructor` ON `subject`.`class_id`=`classes`.`class_id` AND `subject`.`instructor_id`=`instructor`.`instructor_id`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				

				echo "<tr style='background:#000; color:#FFF;'>
	                    <td>$row->class_name</td>
	                    <td>$row->subject_name</td>
	                    <td>$row->subject_tcr</td>
	                    <td>$row->semester</td>
	                    <td>$row->instructor_name</td>
	                                   
	                  </tr>";
			}		
			
		}
	}
	protected function signupInstructorSendMail($arg, $pass){
		// Create the Transport
		$transport = (new Swift_SmtpTransport('smtp.mailtrap.io', 2525))
		  ->setUsername('29be8018692e82')
		  ->setPassword('45210bbdb89c6a')
		;

		// Create the Mailer using your created Transport
		$mailer = new Swift_Mailer($transport);

		// Create a message
		$message = (new Swift_Message('Create Account Requect !'))
		  ->setFrom(['noreply@superioruniversity.com' => 'Our System of Superior University Faisalabad Campus'])
		  ->setTo([$arg['instructor-email']])
		  ->setBody(createInstructorEmailMessageBody($arg,$pass), 'text/html')
		  ;

		// Send the message
		$result = $mailer->send($message);

		if ($result) {
			return true;
		}
		else{
			return false;
		}
	}


	public function setInstructor($arg,$db){
		
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$sql ="INSERT INTO `instructor`(`instructor_code`, `instructor_name`, `instructor_cnic`, `instructor_gender`, `instructor_qualification`, `instructor_email`, `instructor_verification_code`, `instructor_password`, `major_subject`) VALUES (?,?,?,?,?,?,?,?,?) ";
			$stmt = $db->prepare($sql);
			$pass = generateRandomString();
			$hash = password_hash($pass, PASSWORD_DEFAULT);
			$code = generateCode();

			if (is_object($stmt)) {
				$stmt->bindParam(1, $arg['code'], PDO::PARAM_STR);
				$stmt->bindParam(2, $arg['instructor-name'], PDO::PARAM_STR);
				$stmt->bindParam(3, $arg['instructor-cnic'], PDO::PARAM_STR);
				$stmt->bindParam(4, $arg['instructor-gender'], PDO::PARAM_STR);
				$stmt->bindParam(5, $arg['instructor-qualification'], PDO::PARAM_STR);
				$stmt->bindParam(6, $arg['instructor-email'], PDO::PARAM_STR);
				$stmt->bindParam(7, $code, PDO::PARAM_STR);
				$stmt->bindParam(8, $hash, PDO::PARAM_STR);
				$stmt->bindParam(9, $arg['major_subject'], PDO::PARAM_STR);

				$stmt->execute();
				if ($stmt->rowCount()) {
					$this->signupInstructorSendMail($arg,$pass);

					return "success";
				}
				return "error";
			}

		}
		return "input_missing";
		
	}

	public function getInstructorInfo($db){

		$sql ="SELECT * FROM `instructor`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				

				echo "<tr style='background:#000; color:#FFF;'>
	                    <td>$row->instructor_code</td>
	                    <td>$row->instructor_name</td>
	                    <td>$row->instructor_cnic</td>
	                    <td>$row->instructor_gender</td>
	                    <td>$row->instructor_qualification</td>
	                    <td>$row->instructor_email</td>
	                    <td>$row->major_subject</td>               
	                  </tr>";
			}		
			
		}
	}
	
	protected function signupStudentSendMail($arg, $pass){
		// Create the Transport
		$transport = (new Swift_SmtpTransport('smtp.mailtrap.io', 2525))
		  ->setUsername('29be8018692e82')
		  ->setPassword('45210bbdb89c6a')
		;

		// Create the Mailer using your created Transport
		$mailer = new Swift_Mailer($transport);

		// Create a message
		$message = (new Swift_Message('Create Account Requect !'))
		  ->setFrom(['noreply@superioruniversity.com' => 'Administrator Superior University Faisalabad Campus'])
		  ->setTo([$arg['email']])
		  ->setBody(signupStudentEmailMessageBody($arg,$pass), 'text/html')
		  ;

		// Send the message
		$result = $mailer->send($message);

		if ($result) {
			return true;
		}
		else{
			return false;
		}
	}


	public function setStudent($arg,$db){
		
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$sql ="INSERT INTO `student_info`(`st_fullname`, `st_father_name`, `st_gender`, `st_class_id`, `st_roll_no`, `st_registation_no`, `st_session`, `st_email`, `st_verification_code`, `st_password`, `st_department_id`, `st_section`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ";
			$stmt = $db->prepare($sql);
			$pass = generateRandomString();
			$hash = password_hash($pass, PASSWORD_DEFAULT);
			$code = generateCode();

			if (is_object($stmt)) {
				$stmt->bindParam(1, $arg['fullname'], PDO::PARAM_STR);
				$stmt->bindParam(2, $arg['fname'], PDO::PARAM_STR);
				$stmt->bindParam(3, $arg['gender'], PDO::PARAM_STR);
				$stmt->bindParam(4, $arg['class-id'], PDO::PARAM_INT);
				$stmt->bindParam(5, $arg['roll-no'], PDO::PARAM_STR);
				$stmt->bindParam(6, $arg['registation-no'], PDO::PARAM_STR);
				$stmt->bindParam(7, $arg['session'], PDO::PARAM_STR);
				$stmt->bindParam(8, $arg['email'], PDO::PARAM_STR);
				$stmt->bindParam(9, $code, PDO::PARAM_STR);
				$stmt->bindParam(10, $hash, PDO::PARAM_STR);
				$stmt->bindParam(11, $arg['department-id'], PDO::PARAM_INT);
				$stmt->bindParam(12, $arg['section'], PDO::PARAM_STR);

				$stmt->execute();
				if ($stmt->rowCount()) {
					$this->signupStudentSendMail($arg,$pass);

					return "success";
				}
				return "error";
			}

		}
		return "input_missing";
		
	}

	public function getStudent($db){

		$sql ="SELECT * FROM `student_info` JOIN `department` JOIN `classes` ON `student_info`.`st_department_id`=`department`.`department_id` AND `student_info`.`st_class_id`=`classes`.`class_id`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				

				echo "<tr style='background:#000; color:#FFF;'>
	                    <td>$row->st_fullname</td>
	                    <td>$row->st_father_name</td>
	                    <td>$row->st_roll_no</td>
	                    <td>$row->st_registation_no</td>
	                    <td>$row->st_gender</td>
	                    <td>$row->st_email</td>
	                    <td>$row->department_name</td>
	                    <td>$row->class_name</td>
	                    <td>$row->st_section</td>
	                    <td>$row->st_session</td>               
	                  </tr>";
			}		
			
		}
	}
	public function setAcademicResult($arg,$db){
		
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$sql ="INSERT INTO `academic_details`(`student_id`, `subject_id`, `instructor_id`, `semester`, `mid`, `final`, `total`, `max_marks`, `grade`, `gpa`) VALUES (?,?,?,?,?,?,?,?,?,?) ";
			$stmt = $db->prepare($sql);
			
			if (is_object($stmt)) {
				$stmt->bindParam(1, $arg['student-id'], PDO::PARAM_INT);
				$stmt->bindParam(2, $arg['subject-id'], PDO::PARAM_INT);
				$stmt->bindParam(3, $arg['instructor-id'], PDO::PARAM_INT);
				$stmt->bindParam(4, $arg['semester'], PDO::PARAM_STR);
				$stmt->bindParam(5, $arg['mid'], PDO::PARAM_STR);
				$stmt->bindParam(6, $arg['final'], PDO::PARAM_STR);
				$stmt->bindParam(7, $arg['total'], PDO::PARAM_INT);
				$stmt->bindParam(8, $arg['max-marks'], PDO::PARAM_INT);
				$stmt->bindParam(9, $arg['grade'], PDO::PARAM_STR);
				$stmt->bindParam(10, $arg['gpa'], PDO::PARAM_STR);

				$stmt->execute();
				if ($stmt->rowCount()) {
				
					return "success";
				}
				return "error";
			}

		}
		return "input_missing";
		
	}

	public function getAcademicResult($db){

		$sql ="SELECT `academic_details`.`student_id`, `academic_details`.`subject_id`, `academic_details`.`instructor_id`, `academic_details`.`semester`, `academic_details`.`mid`, `academic_details`.`final`, `academic_details`.`total`, `academic_details`.`max_marks`, `academic_details`.`grade`, `academic_details`.`gpa`,`student_info`.`st_fullname`,`student_info`.`st_roll_no`,`subject`.`subject_name`,`instructor`.`instructor_name` FROM `academic_details` JOIN `student_info` JOIN `subject` JOIN `instructor` ON `academic_details`.`student_id`=`student_info`.`st_id` AND `academic_details`.`subject_id`=`subject`.`subject_id` AND `academic_details`.`instructor_id`=`instructor`.`instructor_id`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				

				echo "<tr style='background:#000; color:#FFF;'>
	                    <td>$row->st_fullname</td>
	                    <td>$row->st_roll_no</td>
	                    <td>$row->subject_name</td>
	                    <td>$row->instructor_name</td>
	                    <td>$row->semester-Semester</td>
	                    <td>$row->mid</td>
	                    <td>$row->final</td>
	                    <td>$row->total</td>
	                    <td>$row->max_marks</td>
	                    <td>$row->grade</td>
	                    <td>$row->gpa</td>               
	                  </tr>";
			}		
			
		}
	}
	
	public function setAttendance($arg,$db){
		
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$sql ="INSERT INTO `attendance`(`class_id`, `section`, `subject_id`, `student_id`, `instructor_id`, `nol`, `nop`, `noa`) VALUES (?,?,?,?,?,?,?,?)";
			$stmt = $db->prepare($sql);
			
			if (is_object($stmt)) {
				$stmt->bindParam(1, $arg['class-id'], PDO::PARAM_INT);
				$stmt->bindParam(2, $arg['section'], PDO::PARAM_STR);
				$stmt->bindParam(3, $arg['subject-id'], PDO::PARAM_INT);
				$stmt->bindParam(4, $arg['student-id'], PDO::PARAM_INT);
				$stmt->bindParam(5, $arg['instructor-id'], PDO::PARAM_INT);
				$stmt->bindParam(6, $arg['nol'], PDO::PARAM_STR);
				$stmt->bindParam(7, $arg['nop'], PDO::PARAM_INT);
				$stmt->bindParam(8, $arg['noa'], PDO::PARAM_INT);

				$stmt->execute();
				if ($stmt->rowCount()) {
				
					return "success";
				}
				return "error";
			}

		}
		return "input_missing";
		
	}

	public function getAttendance($db){

		$sql ="SELECT `attendance`.`attendance_id`, `attendance`.`class_id`, `attendance`.`section`, `attendance`.`subject_id`, `attendance`.`student_id`, `attendance`.`instructor_id`, `attendance`.`nol`, `attendance`.`nop`, `attendance`.`noa`,`classes`.`class_name`,`subject`.`subject_name`, `student_info`.`st_fullname`,`instructor`.`instructor_name` FROM `attendance` JOIN `classes` JOIN `subject` JOIN `student_info` JOIN `instructor` ON `attendance`.`class_id`=`classes`.`class_id` AND `attendance`.`subject_id`=`subject`.`subject_id` WHERE `attendance`.`student_id`=`student_info`.`st_id` AND `attendance`.`instructor_id`=`instructor`.`instructor_id`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				

				echo "<tr style='background:#000; color:#FFF;'>
	                    <td>$row->st_fullname</td>
	                    <td>$row->subject_name</td>
	                    <td>$row->instructor_name</td>
	                    <td>$row->class_name</td>
	                    <td>$row->section</td>
	                    <td>$row->nol</td>
	                    <td>$row->nop</td>
	                    <td>$row->noa</td>             
	                  </tr>";
			}		
			
		}
	}

	

	public function setTimeTable($arg,$db){
		
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$sql ="INSERT INTO `time_table`(`subject_id`, `instructor_id`, `time`, `class_id`, `section`, `days`, `semester`) VALUES (?,?,?,?,?,?,?)";
			$stmt = $db->prepare($sql);
			
			if (is_object($stmt)) {
				$stmt->bindParam(1, $arg['subject-id'], PDO::PARAM_INT);
				$stmt->bindParam(2, $arg['instructor-id'], PDO::PARAM_INT);
				$stmt->bindParam(3, $arg['time'], PDO::PARAM_STR);
				$stmt->bindParam(4, $arg['class-id'], PDO::PARAM_INT);
				$stmt->bindParam(5, $arg['section'], PDO::PARAM_STR);
				$stmt->bindParam(6, $arg['days'], PDO::PARAM_STR);
				$stmt->bindParam(7, $arg['semester'], PDO::PARAM_INT);
	
				$stmt->execute();
				if ($stmt->rowCount()) {
				
					return "success";
				}
				return "error";
			}

		}
		return "input_missing";
		
	}

	public function getTimeTable($db){

		$sql ="SELECT `time_table`.`time_table_id`, `time_table`.`subject_id`, `time_table`.`instructor_id`, `time_table`.`time`, `time_table`.`class_id`, `time_table`.`section`, `time_table`.`days`, `time_table`.`semester`, `subject`.`subject_name`, `instructor`.`instructor_name`, `classes`.`class_name` FROM `time_table` JOIN `subject` JOIN `instructor` JOIN `classes` ON `time_table`.`subject_id`=`subject`.`subject_id` WHERE `time_table`.`instructor_id`=`instructor`.`instructor_id` AND `time_table`.`class_id`=`classes`.`class_id`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				

				echo "<tr style='background:#000; color:#FFF;'>
	                    <td>$row->class_name</td>
	                    <td>$row->subject_name</td>
	                    <td>$row->instructor_name</td>
	                    <td>$row->section</td>
	                    <td>$row->semester</td>
	                    <td>$row->days</td>
	                    <td>$row->time</td>            
	                  </tr>";
			}		
			
		}
	}
	public function setFee($arg,$db){
		
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$sql ="INSERT INTO `fee_details`(`student_id`, `fee`, `semester`, `status`) VALUES (?,?,?,?)";
			$stmt = $db->prepare($sql);
			
			if (is_object($stmt)) {
				$stmt->bindParam(1, $arg['student-id'], PDO::PARAM_INT);
				$stmt->bindParam(2, $arg['fee'], PDO::PARAM_INT);
				$stmt->bindParam(3, $arg['semester'], PDO::PARAM_STR);
				$stmt->bindParam(4, $arg['status'], PDO::PARAM_STR);
	
				$stmt->execute();
				if ($stmt->rowCount()) {
				
					return "success";
				}
				return "error";
			}

		}
		return "input_missing";
		
	}

	public function getFee($db){

		$sql ="SELECT `fee`, `semester`, `status`, `st_fullname`, `st_roll_no` FROM `fee_details` JOIN `student_info` ON `fee_details`.`student_id`=`student_info`.`st_id`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				

				echo "<tr style='background:#000; color:#FFF;'>
	                    <td>$row->st_fullname</td>
	                    <td>$row->st_roll_no</td>
	                    <td>$row->semester</td>
	                    <td>$row->fee</td>
	                    <td>$row->status</td>          
	                  </tr>";
			}		
			
		}
	}

	public function setDateSheet($arg,$db){
		
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$sql ="INSERT INTO `date_sheet`(`subject_id`, `date`, `class_id`, `semester`, `time`) VALUES (?,?,?,?,?)";
			$stmt = $db->prepare($sql);
			
			if (is_object($stmt)) {
				$stmt->bindParam(1, $arg['subject-id'], PDO::PARAM_INT);
				$stmt->bindParam(2, $arg['date'], PDO::PARAM_STR);
				$stmt->bindParam(3, $arg['class-id'], PDO::PARAM_INT);
				$stmt->bindParam(4, $arg['semester'], PDO::PARAM_STR);
				$stmt->bindParam(5, $arg['time'], PDO::PARAM_STR);
	
				$stmt->execute();
				if ($stmt->rowCount()) {
				
					return "success";
				}
				return "error";
			}

		}
		return "input_missing";
		
	}

	public function getDateSheet($db){

		$sql ="SELECT * FROM `date_sheet` JOIN `classes` JOIN `subject` ON `date_sheet`.`subject_id`=`subject`.`subject_id` AND `date_sheet`.`class_id`=`classes`.`class_id`;";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				

				echo "<tr style='background:#000; color:#FFF;'>
	                    <td>$row->class_name</td>
	                    <td>$row->subject_name</td>
	                    <td>$row->semester</td>
	                    <td>$row->date</td>
	                    <td>$row->time</td>          
	                  </tr>";
			}		
			
		}
	}

	public function setUniversityNotics($arg,$db){
		
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$sql ="INSERT INTO `university_notices`(`notices`, `notice_date`) VALUES(?,?)";
			$stmt = $db->prepare($sql);
			
			if (is_object($stmt)) {
				$stmt->bindParam(1, $arg['notices'], PDO::PARAM_STR);
				$stmt->bindParam(2, $arg['notice_date'], PDO::PARAM_STR);
	
				$stmt->execute();
				if ($stmt->rowCount()) {
				
					return "success";
				}
				return "error";
			}

		}
		return "input_missing";
		
	}

	public function getUniversityNoyics($db){

		$sql ="SELECT * FROM `university_notices` ORDER BY `university_notices`.`id` DESC  LIMIT 1;";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				
			
				echo "$row->notice_date<br>$row->notices";
			}		
			
		}
	}

	
	

// Admin class end	
}

$admin = new Admin;