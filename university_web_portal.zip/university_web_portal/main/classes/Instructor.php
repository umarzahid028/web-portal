<?php 


/**
* 
*/
class Instructor extends Student {

	public function login($arg, $db){
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$status = $this->validate_sanitize_login($arg);
			if (is_array($status)) {
				$status = $this->instructorAuthenticate($status, $db);
				return $status;
				
			}
			else{
				return "error";
			}
		}
		else{
			return $status;
		}
	}
	private function instructorAuthenticate($arg, $db){

		$user_id  = $arg['user-id'];
		$password = $arg['password'];
		$duration =5000;


		$sql = "SELECT `instructor_id`,`instructor_name`,`instructor_code`,`instructor_email`,`instructor_password` FROM `instructor` WHERE `instructor_code`=?";
		$stmt = $db->prepare($sql);

		if ( is_object($stmt) ) {
			$stmt->bindParam(1,$user_id, PDO::PARAM_STR);
			$stmt->execute();

			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
				if ( password_verify( $password, $row->instructor_password )) {
					
					$_SESSION['logged_in']=[

						'id'             =>$row->instructor_id,
						'fullname'       =>$row->instructor_name,
						'email'          =>$row->instructor_email,
						'registation_no' =>$row->instructor_code,
						'account_type'   =>'instructor',
						'start-time'     =>time(),
						'duration'       =>$duration
					];
					session_regenerate_id(true);
					return 'success';
				}
				return 'error';
			}
		}
	}


	public function instructorChangePassword($arg, $db){
		/*
		* make sure to grab all form data
		* sanitization all input
		* check if the old password is valid
		* new password and confirm new password are metched
		*/
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$status = $this->validate_sanitize_change_password($arg);
			if (is_array($status)) {
				$status = $this->instructorPasswordExistsValidate($arg, $db);
				if ($status === true) {
					$status = $this->instructorUpdatePassword($arg, $db);
					return $status;
				}
				return $status;
			}
			else{
				return "error";
			}
		}
		else{
			return $status;
		}
	}
	private function instructorPasswordExistsValidate($arg, $db){

		$id = $arg['id'];
		$old_password = $arg['old-password'];
		
		$sql = "SELECT `instructor_id`,`instructor_password` FROM `instructor` WHERE `instructor_id`=?";
		$stmt = $db->prepare($sql);

		if ( is_object($stmt) ) {
			$stmt->bindParam(1, $id, PDO::PARAM_INT);
			$stmt->execute();

			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
				if ( password_verify( $old_password, $row->instructor_password )) {
					
					if ($arg['npassword'] !== $arg['cpassword'] ) {
					
						return "mismatch_password";
					}
				    return true;
				}
				return 'old_password_wrong';
			}	
		}
	}

	private function instructorUpdatePassword($arg, $db){
		$sql = "UPDATE `instructor` SET `instructor_password`=? WHERE `instructor_id`=?";
		$stmt = $db->prepare($sql);

		if (is_object($stmt)) {
			$hash = password_hash($arg['cpassword'], PASSWORD_DEFAULT);
			$id = $arg['id'];

			$stmt->bindParam(1,$hash, PDO::PARAM_STR);
			$stmt->bindParam(2,$id, PDO::PARAM_STR);
			$stmt->execute();

			if ($stmt->rowCount() == 1) {
				return 'success';
			}
			return 'error';
		}
	}
	public function instructorMailPasswordLink($arg, $db){

		/*
		* make sure to grab all form data
		* check the email exists in database
		*/

		$status = $this->input_recieved($arg);
		if ($status === true) {
			$status = $this->validate_sanitize_email($arg);
			if ($status === true) {
				$status = $this->instructorEmailExists($arg,$db);
				if ($status === true) {
					return "success";
				}
				else{
					return $status;
				}
			}
			else{
				return $status;
			}
		}
		else{
			return $status;
		}
	}

	private function instructorEmailExists($arg,$db){

		$sql ="SELECT * FROM `instructor` WHERE `instructor_email`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg['email'], PDO::PARAM_STR);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
				$status=$this->instructorSendMail($row);

				return true;
			}
			return "no_found";
		}
	}

	public function instructorUpdateResetPassword($arg, $db){
		/*
		* All fields data received
		* new password and confirm password macthed
		* user id is valid
		* varification code is valid
		*/
		$status = $this->input_recieved($arg);
		if ($status === true) {
			$status = $this->passwordMatchedOrNot($arg);
			if ($status === true) {
				$status = $this->instructorIdExists($arg,$db);
				if ($status === true) {
					$status = $this->instructorCodeExists($arg,$db);
					if ($status === true) {
						$status = $this->instructorResetUpdatePassword($arg,$db);
						if ($status === true) {
							
							return $status = "success";
						}
						else{
							return "error";
						}
					}
					else{
						$this->instructorRegenerteCode($arg,$db);
						$row = $this->getInstructorDtetails($arg,$db);
						$this->instructorSendMail($row);
						return $status;
					}
				}
				else{
					return $status;
				}
			}
			else{
				return $status;
			}
		}
		else{
			return $status;
		}
	}                


	private function instructorIdExists($arg,$db){

		$sql ="SELECT `instructor_id` FROM `instructor` WHERE `instructor_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
				if ($arg['id'] === $row->instructor_id) {
					return true;
				}
				
			}
			return "incorrect_id";
		}
	}
	private function instructorCodeExists($arg,$db){

		$sql ="SELECT `instructor_verification_code` FROM `instructor` WHERE `instructor_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
			
				if ($arg['code'] === $row->instructor_verification_code	) {

					return true;
				}
				
			}
			return "incorrect_code";
		} 
	}

	private function instructorRegenerteCode($arg,$db){

		$sql ="UPDATE `instructor` SET `instructor_verification_code`=? WHERE `instructor_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$code = generateCode();
			$stmt->bindParam(1, $code, PDO::PARAM_STR);
			$stmt->bindParam(2, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($stmt->rowCount()) {

				return true;
			}
			return "errror";
		}
	}

	private function getInstructorDtetails($arg,$db){

		$sql ="SELECT * FROM `instructor` WHERE `instructor_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$code = generateCode();
			$stmt->bindParam(1, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {

				return $row;
			}
			return false;
		}
	}

	private function instructorResetUpdatePassword($arg,$db){

		$sql ="UPDATE `instructor` SET `instructor_password`=?, `instructor_verification_code`=? WHERE `instructor_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$hash = password_hash($arg['cpassword'], PASSWORD_DEFAULT);
			$code = generateCode();

			$stmt->bindParam(1, $hash, PDO::PARAM_STR);
			$stmt->bindParam(2, $code, PDO::PARAM_STR);
			$stmt->bindParam(3, $arg['id'], PDO::PARAM_INT);
			$stmt->execute();
			if ($stmt->rowCount()) {

				return true;
			}
			return "error";
		}
	}
	protected function instructorSendMail($arg){
		// Create the Transport
		$transport = (new Swift_SmtpTransport('smtp.mailtrap.io', 2525))
		  ->setUsername('29be8018692e82')
		  ->setPassword('45210bbdb89c6a')
		;

		// Create the Mailer using your created Transport
		$mailer = new Swift_Mailer($transport);

		// Create a message
		$message = (new Swift_Message('Password Recovery Request !'))
		  ->setFrom(['noreply@superioruniversity.com' => 'Administrator of Superior University Faisalabad Campus'])
		  ->setTo([$arg->instructor_email])
		  ->setBody(instructorPasswordRecoverEmailMessageBody($arg), 'text/html')
		  ;

		// Send the message
		$result = $mailer->send($message);

		if ($result) {
			return true;
		}
		else{
			return false;
		}
	}


	public function getInstructorInfo($arg,$db){
		// getter-> information instructor

		$sql ="SELECT * FROM `instructor` WHERE `instructor_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg, PDO::PARAM_INT);
			$stmt->execute();
			if ($row = $stmt->fetch(PDO::FETCH_OBJ)) {

				return $row;
			}
			return false;
		}
	}

	public function set_instructor_assignment($arg, $db){

		$upload_directory  = "uploads/";
		$filename 		   = $_FILES['file']['name'];
		$upload_directory .= $filename;
		$tmp_dir		   = $_FILES['file']['tmp_name'];
		$size 			   = $_FILES['file']['size'];

		 move_uploaded_file($tmp_dir, $upload_directory);

		$sql = "INSERT INTO `assignment`(`class_id`, `subject_id`, `submission_date`, `assignment_url`, `instructor_id`, `section`, `term`) VALUES(?,?,?,?,?,?,?)";
		$stmt = $db->prepare($sql);

		if (is_object($stmt)) {
			
			$stmt->bindParam(1,$arg['class-id'], PDO::PARAM_INT);
			$stmt->bindParam(2,$arg['subject-id'], PDO::PARAM_INT);
			$stmt->bindParam(3,$arg['submission-date'], PDO::PARAM_STR);
			$stmt->bindParam(4,$upload_directory, PDO::PARAM_STR);
			$stmt->bindParam(5,$arg['instructor-id'], PDO::PARAM_INT);
			$stmt->bindParam(6,$arg['section'], PDO::PARAM_STR);
			$stmt->bindParam(7,$arg['term'], PDO::PARAM_STR);
			$stmt->execute();

			if ($stmt->rowCount() == 1) {
				return 'success';
			}
			return 'error';
		}
	}

	public function getClasses($db){
		// getter 
		$sql ="SELECT `class_id`, `class_name` FROM `classes`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				
				echo "<option value='$row->class_id'>$row->class_name</option>";		
			}		
		}
	}
	public function getSubjects($db){
		// getter 
		$sql ="SELECT `subject_id`, `subject_name` FROM `subject`";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				
				echo "<option value='$row->subject_id'>$row->subject_name</option>";		
			}		
		}
	}

	public function getAssignmentDetails($session,$db){
		// get information assignment

		$sql ="SELECT `assignment`.`submission_date`, `assignment`.`assignment_url`, `assignment`.`section`,`assignment`.`term`,`classes`.`class_name`,`subject`.`subject_name` FROM `assignment` JOIN `classes` JOIN `subject` ON `assignment`.`class_id` = `classes`.`class_id` AND `assignment`.`subject_id`= `subject`.`subject_id` WHERE `assignment`.`instructor_id`=?";
		$stmt = $db->prepare($sql);
		if (is_object($stmt)) {
			$stmt->bindParam(1, $session, PDO::PARAM_INT);
			$stmt->execute();
			while ( $row = $stmt->fetch(PDO::FETCH_OBJ)) {
				

				echo "<tr style='background:#000; color:#FFF;'>
	                    <td>$row->submission_date</td>
	                    <td>$row->term</td>
	                    <td>$row->class_name</td>
	                    <td>$row->subject_name</td>
	                    <td>$row->section</td>
	                    <td>$row->assignment_url</td>              
	                  </tr>";
			}			
		}
	}

	public function instructorMassagesForstufents($arg,$db){

		$sql ="INSERT INTO `instructor_messages`(`instructor_id`, `class_id`, `section`, `title`, `data_time`, `messages`) VALUES (?,?,?,?,?,?) ";
		$stmt = $db->prepare($sql);
		$date = date("d-m-Y");
		if (is_object($stmt)) {
			$stmt->bindParam(1, $arg['session'], PDO::PARAM_INT);
			$stmt->bindParam(2, $arg['class-id'], PDO::PARAM_INT);
			$stmt->bindParam(3, $arg['section'], PDO::PARAM_STR);
			$stmt->bindParam(4, $arg['title'], PDO::PARAM_STR);
			$stmt->bindParam(5, $date, PDO::PARAM_STR);
			$stmt->bindParam(6, $arg['message'], PDO::PARAM_STR);
			
			$stmt->execute();
			if ($stmt->rowCount()) {

				return true;
			}
			return "error";
		}
	}




// instructor class end	
}

$instructor = new Instructor;