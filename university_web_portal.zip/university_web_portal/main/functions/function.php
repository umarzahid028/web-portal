<?php
function debug($arg){
	echo "<pre>";
	print_r($arg);
	echo "</pre>";
	exit();
}

function generateCode(){
	return md5(random_bytes(32));
}

function passwordRecoverEmailMessageBody($arg){

	$url  = 'http://localhost/university_web_portal/recovery-password-link.php?id='.$arg->st_id;
	$url .= '&code='.$arg->st_verification_code;

	$html  = '<p>';
	$html .= 'Hello ' . $arg->st_fullname;
	$html .= '<br><br> We just receive a request to sent your password recovery link</p>';
	$html .= '<p> Click this link to recover your password ';
	$html .= '<b><a href="'. $url .'">Recover Password</a></b></p>';
	$html .= '<br><hr>';
	$html .= 'If you think you did not make this request, just ignore this email';

	return $html ;
}

function instructorPasswordRecoverEmailMessageBody($arg){

	$url  = 'http://localhost/university_web_portal/instructor/recovery-password-link.php?id='.$arg->instructor_id;
	$url .= '&code='.$arg->instructor_verification_code;

	$html  = '<p>';
	$html .= 'Hello ' . $arg->instructor_name;
	$html .= '<br><br> We just receive a request to sent your password recovery link</p>';
	$html .= '<p> Click this link to recover your password ';
	$html .= '<b><a href="'. $url .'">Recover Password</a></b></p>';
	$html .= '<br><hr>';
	$html .= 'If you think you did not make this request, just ignore this email';

	return $html ;
}

function adminPasswordRecoverEmailMessageBody($arg){

	$url  = 'http://localhost/university_web_portal/admin/recovery-password-link.php?id='.$arg->id;
	$url .= '&code='.$arg->verification_code;

	$html  = '<p>';
	$html .= 'Hello ' . $arg->fullname;
	$html .= '<br><br> We just receive a request to sent your password recovery link</p>';
	$html .= '<p> Click this link to recover your password ';
	$html .= '<b><a href="'. $url .'">Recover Password</a></b></p>';
	$html .= '<br><hr>';
	$html .= 'If you think you did not make this request, just ignore this email';

	return $html ;
}

function createInstructorEmailMessageBody($arg,$pass){

	$html  = '<p>';
	$html .= 'Hello ' . $arg['instructor-name'];
	$html .= '<br><br><h1>Your account has been created</h1></p>';
	$html .= '<p>Code / ID : ' .$arg['code'];
	$html .= '<br>Password : ' .$pass. '</p>';
	$html .= '<br><hr>';
	$html .= 'If you think you did not make this request create your account, just ignore this email';

	return $html ;
}

function signupStudentEmailMessageBody($arg,$pass){

	$html  = '<p>';
	$html .= 'Hello ' . $arg['fullname'];
	$html .= '<br><br><h1>Your account has been created</h1></p>';
	$html .= '<p>Code / ID : ' .$arg['registation-no'];
	$html .= '<br>Password : ' .$pass. '</p>';
	$html .= '<br><hr>';
	$html .= 'If you think you did not make this request create your account, just ignore this email';

	return $html ;
}


function generateRandomString($length = 8) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}