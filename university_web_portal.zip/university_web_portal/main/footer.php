

<footer style="background:rgba(1, 2, 1, 0.6); color: #ffffff;">
   <div class="pull-right" >
         © 2018 Superior University. All rights reserved | Created by <a href="group_member.php">Group Memeber</a>
          </div>
          <div class="clearfix"></div>
</footer>
  
</body>
</html>