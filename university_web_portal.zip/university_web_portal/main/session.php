<?php 
session_regenerate_id(true);

if (isset($_SESSION['logged_in'])) {
    if ($_SESSION['logged_in']['account_type'] == 'instructor') {
		
		$start = $_SESSION['logged_in']['start-time'];
		$duration = $_SESSION['logged_in']['duration'];
			if ((time() - $start) > $duration) {
				unset($_SESSION['logged_in']['duration']);
				unset($_SESSION['logged_in']['start-time']);
				unset($_SESSION['logged_in']['fullname']);
				unset($_SESSION['logged_in']);
				session_destroy();
				header("Location: ../instructor/index.php?status= Session has been expired");
			}
          //return header("Location: ../instructor/profile.php");
    }


    elseif ($_SESSION['logged_in']['account_type'] == 'student') {

    	$start = $_SESSION['logged_in']['start-time'];
		$duration = $_SESSION['logged_in']['duration'];
			if ((time() - $start) > $duration) {
				unset($_SESSION['logged_in']['duration']);
				unset($_SESSION['logged_in']['start-time']);
				unset($_SESSION['logged_in']['fullname']);
				unset($_SESSION['logged_in']);
				session_destroy();
				header("Location: ../index.php?status= Session has been expired");
			}
         
           //return header("Location: ../main/index.php");
      } 
      elseif ($_SESSION['logged_in']['account_type'] == 'admin') {
      	$start = $_SESSION['logged_in']['start-time'];
		$duration = $_SESSION['logged_in']['duration'];
			if ((time() - $start) > $duration) {
				unset($_SESSION['logged_in']['duration']);
				unset($_SESSION['logged_in']['start-time']);
				unset($_SESSION['logged_in']['fullname']);
				unset($_SESSION['logged_in']);
				session_destroy();
				header("Location: ../admin/index.php?status= Session has been expired");
			}
          
        //return header("Location: ../admin/profile.php");
      } 
 } 

else{
	header("Location: ../index.php");
 }


