
<html>
<head>
    <title>Group Member</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <style type="text/css">
         body{
            margin-top: 30px !important;
            font-family: Helvetica,Arial,sans-serif;
        }
        h3{
            margin: 0;
        }
        .our-team{
            text-align: center;
            position: relative;
            color: #fff;
        }
        .our-team:before{
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            transition:all 0.3s ease 0s;
            opacity: 0;
        }
        .our-team:hover:before{
            opacity: 1;
        }
        .our-team img{
            width: 100%;
            height: auto;
        }
        .our-team .team-content{
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            padding: 30px 0;
            background-color: rgba(134,16,74,0.9);
            transition:all 0.3s ease 0s;
        }
        .our-team:hover .team-content{
            bottom: 20%;
        }
        .our-team .team-content .name{
            font-size: 22px;
            font-weight: 800;
            letter-spacing: 1px;
            display: block;
            margin-bottom: 7px;
            text-transform: uppercase;
            transition:all 0.3s ease 0s;
        }
        .our-team:hover .team-content .name{
            transform:translateY(30px);
            transition-delay:0.3s;
        }
        .our-team .team-content .post{
            font-size: 17px;
            display: block;
            transition:all 0.3s ease 0s;
            text-transform: capitalize;
        }
        .our-team:hover .team-content .post{
            transform:translateY(-30px);
            transition-delay:0.3s;
        }

        @media screen and (max-width:990px){
            .our-team{
                margin-bottom: 30px !important;
            }
        }
    </style>
    
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-4 col-sm-6">
            <div class="our-team">
                <img src="https://images.pexels.com/photos/157646/title-photo-logo-shirt-157646.jpeg?w=940&h=650&auto=compress&cs=tinysrgb" alt="team member" class="img-responsive">
                <div class="team-content">
                    <h3 class="name">Peter</h3>
                    <span class="post">web designer</span>
                </div>
            </div>
        </div>

        <div class="col-md-4 col-sm-6">
            <div class="our-team">
                <img src="https://static.pexels.com/photos/38554/girl-people-landscape-sun-38554.jpeg" alt="team member" class="img-responsive">
                <div class="team-content">
                    <h3 class="name">Kellie Smith</h3>
                    <span class="post">web designer</span>
                </div>
            </div>
        </div>

        <div class="col-md-4 col-sm-6">
            <div class="our-team">
                <img src="https://images.pexels.com/photos/157646/title-photo-logo-shirt-157646.jpeg?w=940&h=650&auto=compress&cs=tinysrgb" alt="team member" class="img-responsive">
                <div class="team-content">
                    <h3 class="name">Johnson</h3>
                    <span class="post">web designer</span>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>