<?php 
session_start();

if (isset($_SESSION['logged_in'])) {
	 
	 $_SESSION['logged_in']= [];
	 if (ini_get('session.use_cookies')) {
	 	

	 	setcookie(session_name(), session_id(), time()-1000, "/");
	 }
	 unset($_SESSION['logged_in']);
	 session_destroy();
	 
	 header("Location:../index.php");

}
else{
	header("Location: ../index.php?error=Please login your account");
 }




?>
