<?php 
require_once '../main/includes/init.php';
require_once '../main/session.php';
require_once('../main/header.php'); 
require_once('../main/css.php');

if (isset($_SESSION['logged_in'])) {
      if ($_SESSION['logged_in']['account_type'] == 'instructor') {
           
           return header("Location: ../instructor/profile.php");
      }
      elseif ($_SESSION['logged_in']['account_type'] == 'student') {
          
           return header("Location: index.php");
      } 
      elseif ($_SESSION['logged_in']['account_type'] == 'admin') {
          
           //return header("Location: ../admin/index.php");
      } 
 } 

  
?>
<style type="text/css">
  .nav_color{background-color: #000000;}
</style>
  <body class="nav-sm" style="background-image:url(../banner1.jpg);">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view nav_color">
            <div class="navbar nav_title nav_color">
              <a href="profile.php" class="site_title"><i class="fa fa-university"></i></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile">
              <div class="profile_pic">
                <img src="../public/images/user.png" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2>Admin</h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />
            <?php require_once('../main/sidebar_nav.php'); ?>   
        <!-- page content -->
        <div class="right_col" role="main" style="background-color:transparent;">
          <div class="">
            <div class="page-title">
              <div class="title_left">
              </div>
              </div>
            </div>

        <!--Assignment add and details  -->

             
<!-- Add Assignment -->
      <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bs-example-modal-sm" c>&nbsp;&nbsp;&nbsp;&nbsp;Add Subjects&nbsp;&nbsp;&nbsp;&nbsp;</button>
       <div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
         <div class="modal-dialog modal-sm">
            <div class="modal-content">
            <div class="modal-header" >
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
              </button>
               <h4 id="myModalLabel2">&nbsp;Add Subjects</h4>
            </div>
            <div class="modal-body">
              <div class="parent">
            <form class="form-horizontal form-label-left form" action="save-add-subject.php" method="POST" >
            
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-3">Subject</label>
                <div class="col-md-9 col-sm-9 col-xs-9">
                  <input type="text" class="form-control" name="subject-name" placeholder="Subject Name">
                  <span class="form-control-feedback right" aria-hidden="true"><i class="fa fa-book"></i></span>   
                </div>
            </div> 

            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-3">Class</label>
              <div class="col-md-9 col-sm-9 col-xs-9">
                <select class="form-control" name="class-id">
                  <?php $admin->getClasses($db);?>
                </select>
                <span class="form-control-feedback right" aria-hidden="true"><i class="fa fa-eyedropper"></i></span>
              </div>
            </div>   
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-3">TCH</label>
              <div class="col-md-9 col-sm-9 col-xs-9">
                <select class="form-control" name="subject-tcr">
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                </select>
                <span class="form-control-feedback right" aria-hidden="true"><i class="fa fa-clock-o"></i></span>
              </div>
            </div>   
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-3">Semester</label>
              <div class="col-md-9 col-sm-9 col-xs-9">
                <select class="form-control" name="semester">
                  <option value="1-semester">1-semester</option>
                  <option value="2-semester">2-semester</option>
                  <option value="3-semester">3-semester</option>
                  <option value="4-semester">4-semester</option>
                  <option value="5-semester">5-semester</option>
                  <option value="6-semester">6-semester</option>
                  <option value="7-semester">7-semester</option>
                  <option value="8-semester">8-semester</option>
                </select>
                <span class="form-control-feedback right" aria-hidden="true"><i class="fa fa-clock-o"></i></span>
              </div>
            </div>   
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-3">Instructor</label>
              <div class="col-md-9 col-sm-9 col-xs-9">
                <select class="form-control" name="instructor-id">
                  <?php $admin->getInstructor($db);?>
                </select>
                <span class="form-control-feedback right" aria-hidden="true"><i class="fa fa-user"></i></span>
              </div>
            </div>     
            <div class="form-group">
              <div class="col-md-9 col-md-offset-3">
                <button type="submit" class="btn btn-success btn-lg">Submit</button>
              </div>
            </div>
         </form>
       </div>
       <div class="footer"> </div>
       </div>
      </div>
     </div>
    </div>
   <!-- /modals -->
               
            
              <table id="datatable-buttons" width="100%" class="table table-striped table-bordered" style="color:#FFF;">
              <thead style="background:#000; color:#FFF;">
                <tr>
                  <th>Class Name</th>
                  <th>Subject Name</th>   
                  <th>TCH</th>                     
                  <th>Semester</th>                     
                  <th>Instructor Name</th>                     
                                       

                </tr>
              </thead>
            <tbody>
                                                
                    
                <?php $admin->getSubjectInfo($db); ?>
             
            </tbody>
            </table>
                  </div>
                </div>
              </div>

              
              
          </div>
 
            <!--  -->
                   
                    </div>

                  </div>
                </div>
              </div>                
          <div class="clearfix"></div>
        </div>
        <!-- /page content -->

        
      </div>
    </div>

    



<!-- footer content -->
       <?php require_once('../main/footer.php');?>
        <!-- /footer content --><!-- jQuery -->
    
<!-- JavaScript files --> 
  <?php require_once('../main/js.php');?>
 <!-- JavaScript files-->



 <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdf",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
    
    