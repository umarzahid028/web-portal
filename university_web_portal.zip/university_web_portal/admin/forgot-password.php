<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Superior University Web Portal FSD</title>
  <link rel="shortcut icon" href="../public/images/logo.png">
  <link rel="stylesheet" href="../public/css/login.css">


</head>
<body>
  <div id="logo"> 
  <h1><i>Superior Univarsity FSD<br>Reset Passwoed Link</i></h1>
</div> 
<section class="stark-login">
  <div class="parent">
  <form action="mail-password-link.php" method="POST" class="form">	
    <div id="fade-box">
      <input type="text" name="email" id="username" placeholder="Email @">
          <input type="submit" name="submit" value="Send Passwoed Link">
               
      </div>
      </form>
      </div>
<div class="footer">
  
</div>
      
      <div class="hexagons">
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <br>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <br>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span> 
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            
            <br>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <br>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
              </div>      
            </section> 
            <div id="circle1">
              <div id="inner-cirlce1">
                <h2></h2>
              </div>
            </div>
            <script src="../public/js/jquery.min.js"></script>
            <script src="../public/js/script.js"></script>
    

</body>
</html>
