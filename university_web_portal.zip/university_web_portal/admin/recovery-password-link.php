<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Superior University Web Portal FSD</title>
  <link rel="shortcut icon" href="../public/images/logo.png">
  <link rel="stylesheet" href="../public/css/login.css">


</head>
<body>
  <div id="logo"> 
  <h1><i>Superior Univarsity FSD<br>Update Password</i></h1>
</div> 
<section class="stark-login">
  <div class="parent">
  <form action="update-reset-password.php" method="POST" class="form">	
    <div id="fade-box">
      <input type="hidden" name="id" value="<?=$_GET['id'];?>">
      <input type="hidden" name="code" value="<?=$_GET['code'];?>">
      <input type="password" name="npassword" id="npassword" placeholder="New Password">
      <input type="password" name="cpassword" id="cpassword" placeholder="Confirm Password">
          <input type="submit" name="submit" value="Reset Password">
          <a href="index.php" style="font-size: 18px; text-decoration: none; color: gray">Login your account?</a>
               
      </div>
      </form>
      </div>
<div class="footer">
  
</div>
      
      <div class="hexagons">
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <br>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <br>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span> 
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            
            <br>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <br>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
              </div>      
            </section> 
            <div id="circle1">
              <div id="inner-cirlce1">
                <h2></h2>
              </div>
            </div>
            <script src="../public/js/jquery.min.js"></script>
            <script src="../public/js/script.js"></script>
    

</body>
</html>
