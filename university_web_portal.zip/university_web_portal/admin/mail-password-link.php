<?php 
require_once '../main/includes/init.php';

$status = $admin->adminMailPasswordLink($_POST, $db);

if ($status === 'success') {
    echo json_encode([
        'success'=>'success',
        'message'=>'<div class="success">We sent you email with password reset link!</div>',
        'signout'=>1
    ]);
}
else if ($status === 'input_missing') {
    echo json_encode([
        'error'=>'error',
        'message'=>'<div class="error">Email field is required !</div>'
    ]);
}
else if ($status === 'wrong_formet') {
    echo json_encode([
        'error'=>'error',
        'message'=>'<div class="error">Email Incorrect Formet!</div>'
    ]);
}
else if ($status === 'no_found') {
    echo json_encode([
        'error'=>'error',
        'message'=>'<div class="error">Email is not found!</div>'
    ]);
}