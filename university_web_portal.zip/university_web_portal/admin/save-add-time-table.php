<?php 
require_once '../main/includes/init.php';

$status = $admin->setTimeTable($_POST, $db);


if ($status === 'success') {
    echo json_encode([
        'success'=>'success',
        'message'=>'
        <div class="alert alert-success alert-dismissible fade in">
            <strong>Success !</strong> Result has been Updated!
        </div>',
        'signout'=>1
    ]);
}

else if ($status === 'error') {
    echo json_encode([
        'error'=>'error',
        'message'=>'
        <div class="alert alert-danger alert-dismissible fade in">
            <strong>Failed !</strong> Data alreasy exists
        </div>'
    ]);
}
else if ($status === 'input_missing') {
    echo json_encode([
        'error'=>'error',
        'message'=>'<div class="alert alert-danger alert-dismissible fade in">
         
          <strong>Error !</strong> Field is mandatory
        </div>'
    ]);
}
 