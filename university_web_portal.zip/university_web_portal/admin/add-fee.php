<?php 
require_once '../main/includes/init.php';
require_once '../main/session.php';
require_once('../main/header.php'); 
require_once('../main/css.php'); 


if (isset($_SESSION['logged_in'])) {
      if ($_SESSION['logged_in']['account_type'] == 'instructor') {
           
           return header("Location: ../instructor/profile.php");
      }
      elseif ($_SESSION['logged_in']['account_type'] == 'student') {
          
           return header("Location: index.php");
      } 
      elseif ($_SESSION['logged_in']['account_type'] == 'admin') {
          
           //return header("Location: ../admin/index.php");
      } 
 } 
 
?>
<style type="text/css">
  .nav_color{background-color: #000000;}
</style>
  <body class="nav-sm" style="background-image:url(../banner1.jpg);">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view nav_color">
            <div class="navbar nav_title nav_color">
              <a href="profile.php" class="site_title"><i class="fa fa-university"></i></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile">
              <div class="profile_pic">
                <img src="../public/images/user.png" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2>Admin</h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />
            <?php require_once('../main/sidebar_nav.php'); ?>   
        <!-- page content -->
        <div class="right_col" role="main" style="background-color:transparent;">
          <div class="">
            <div class="page-title">
              <div class="title_left">
              </div>
              </div>
            </div>

        <!--Assignment add and details  -->

             
<!-- Add Assignment -->
      <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bs-example-modal-sm" c>&nbsp;&nbsp;&nbsp;&nbsp;Add Fee&nbsp;&nbsp;&nbsp;&nbsp;</button>
       <div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
         <div class="modal-dialog modal-sm">
            <div class="modal-content">
            <div class="modal-header" >
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
              </button>
               <h4 id="myModalLabel2">&nbsp;Add Fee</h4>
            </div>
            <div class="modal-body">
              <div class="parent">
            <form class="form-horizontal form-label-left form" action="save-add-fee.php" method="POST" >
            
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-3">Student</label>
                <div class="col-md-9 col-sm-9 col-xs-9">
                  <select class="form-control" name="student-id">
                    <?php $admin->getStudentId($db);  ?>
                   </select>
                  
                  <span class="form-control-feedback right" aria-hidden="true"><i class="fa fa-user"></i></span>   
                </div>
            </div> 
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-3">Semester</label>
                <div class="col-md-9 col-sm-9 col-xs-9">
                  <select class="form-control" name="semester">
                    <option value="1">1-Semester</option>
                    <option value="2">2-Semester</option>
                    <option value="3">3-Semester</option>
                    <option value="4">4-Semester</option>
                    <option value="5">5-Semester</option>
                    <option value="6">6-Semester</option>
                    <option value="7">7-Semester</option>
                    <option value="8">8-Semester</option>
                   </select>
                  <span class="form-control-feedback right" aria-hidden="true"><i class="fa fa-cc-amex"></i></span>   
                </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-3">Fee</label>
                <div class="col-md-9 col-sm-9 col-xs-9">
                  <input type="text" class="form-control" name="fee" placeholder="Fee">
                  <span class="form-control-feedback right" aria-hidden="true"><i class="fa fa-credit-card"></i></span>   
                </div>
            </div> 
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-3">Status</label>
                <div class="col-md-9 col-sm-9 col-xs-9">
                  <select class="form-control" name="status">
                    <option value="Paid">Paid</option>
                    <option value="Unpaid">Unpaid</option>
                   </select>
                  <span class="form-control-feedback right" aria-hidden="true"><i class="fa fa-flag"></i></span>   
                </div>
            </div>
            <div class="form-group">
              <div class="col-md-9 col-md-offset-3">
                <button type="submit" class="btn btn-success btn-lg">Submit</button>
              </div>
            </div>
         </form>
       </div>
       <div class="footer"> </div>
       </div>
      </div>
     </div>
    </div>
   <!-- /modals -->
               
            
              <table id="datatable-buttons" width="100%" class="table table-striped table-bordered" style="color:#FFF;">
              <thead style="background:#000; color:#FFF;">
                <tr>
                  <th>Student Name</th>
                  <th>Roll No</th>     
                  <th>Semester</th>                   
                  <th>Fee</th>                     
                  <th>Status</th>
                </tr>
              </thead>
            <tbody>               
                    
                <?php $admin->getFee($db); ?>
             
            </tbody>
            </table>
                  </div>
                </div>
              </div>

              
              
          </div>
 
            <!--  -->
                   
                    </div>

                  </div>
                </div>
              </div>                
          <div class="clearfix"></div>
        </div>
        <!-- /page content -->

        
      </div>
    </div>

    



<!-- footer content -->
       <?php require_once('../main/footer.php');?>
        <!-- /footer content --><!-- jQuery -->
    
<!-- JavaScript files --> 
  <?php require_once('../main/js.php');?>
 <!-- JavaScript files-->



 <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdf",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
              responsive: true
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();

        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        var $datatable = $('#datatable-checkbox');

        $datatable.dataTable({
          'order': [[ 1, 'asc' ]],
          'columnDefs': [
            { orderable: false, targets: [0] }
          ]
        });
        $datatable.on('draw.dt', function() {
          $('input').iCheck({
            checkboxClass: 'icheckbox_flat-green'
          });
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
    
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               