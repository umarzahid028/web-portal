<?php 
require_once '../main/includes/init.php';
require_once '../main/session.php';
require_once('../main/header.php'); 
require_once('../main/css.php');

if (isset($_SESSION['logged_in'])) {
      if ($_SESSION['logged_in']['account_type'] == 'instructor') {
           
           //return header("Location: profile.php");
      }
      elseif ($_SESSION['logged_in']['account_type'] == 'student') {
          
           return header("Location: index.php");
      } 
      elseif ($_SESSION['logged_in']['account_type'] == 'admin') {
          
           return header("Location: ../admin/index.php");
      } 
 } 

?>
<style type="text/css">
  .nav_color{background-color: #000000;}
</style>
  <body class="nav-sm" style="background-image:url(../banner1.jpg);">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view nav_color">
            <div class="navbar nav_title nav_color">
              <a href="index.php" class="site_title"><i class="fa fa-university"></i></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile">
              <div class="profile_pic">
                <img src="../public/images/user.png" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2>Admin</h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />
            <?php require_once('../main/sidebar_nav.php'); ?>   
        <!-- page content -->
        <div class="right_col" role="main" style="background-color:transparent;">
          <div class="">
            <div class="page-title">
              <div class="title_left">
              </div>
              </div>
            </div>

            <!--  -->

             <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Change Password</h2>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  

                  <div class="parent">
                    <form class="form-horizontal form-label-left form" action="save_change_password.php" method="POST">
                      <input type="hidden" name="id" value="<?= $_SESSION['logged_in']['id']?>">
                      <div class="item form-group">
                        <label for="password" class="control-label col-md-3">Old Password</label>
                        <div class="col-md-2 col-sm-2 col-xs-12">
                          <input id="password" type="password" name="old-password" data-validate-length="6,8" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                      <div class="item form-group">
                        <label for="password" class="control-label col-md-3">New Password</label>
                        <div class="col-md-2 col-sm-2 col-xs-12">
                          <input id="password" type="password" name="npassword" data-validate-length="6,8" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                      <div class="item form-group">
                        <label for="password2" class="control-label col-md-3 col-sm-3 col-xs-12">Repeat Password</label>
                        <div class="col-md-2 col-sm-2 col-xs-12">
                          <input type="password" name="cpassword" data-validate-linked="cpassword" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                      
                      
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">
                          <button type="submit" class="btn btn-primary">Cancel</button>
                          <button id="send" type="submit" class="btn btn-success">Submit</button>
                        </div>
                      </div>
                    </form>
                  </div>
                  <div class="footer">
                    
                  </div>




                </div>
              </div>
            </div>


            <!--  -->

            
					           
                        
                      
                    </div>

                  </div>
                </div>
              </div>                
          <div class="clearfix"></div>
        </div>
        <!-- /page content -->

        
      </div>
    </div>

    



<!-- footer content -->
       <?php require_once('../main/footer.php');?>
        <!-- /footer content --><!-- jQuery -->
    
<!-- JavaScript files --> 
  <?php require_once('../main/js.php');?>
 <!-- JavaScript files-->



 