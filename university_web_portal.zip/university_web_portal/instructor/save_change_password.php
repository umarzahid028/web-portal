<?php 
require_once '../main/includes/init.php';

$status = $instructor->instructorChangePassword($_POST, $db);



if ($status === 'success') {
    echo json_encode([
        'success'=>'success',
        'message'=>'
        <div class="alert alert-success alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
            </button>
            <strong>Success !</strong> Update password Successfully !
        </div>',
        'signout'=>1
    ]);
}
else if ($status === 'input_missing') {
    echo json_encode([
        'error'=>'error',
        'message'=>'<div class="alert alert-danger alert-dismissible fade in" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
         </button>
          <strong>Error !</strong> All fields mandatory
        </div>'
    ]);
}
else if ($status === 'error') {
    echo json_encode([
        'error'=>'error',
        'message'=>'
        <div class="alert alert-danger alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
            </button>
            <strong>Error !</strong> Failed to change password !
        </div>'
    ]);
}
else if ($status === 'old_password_wrong') {
    echo json_encode([
        'error'=>'error',
        'message'=>'
        <div class="alert alert-danger alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
            </button>
            <strong>Error !</strong> Old Password does not match !
        </div>'
    ]);
}
else if ($status === 'mismatch_password') {
    echo json_encode([
        'error'=>'error',
        'message'=>'
        <div class="alert alert-danger alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
            </button>
            <strong>Error !</strong> Mismatch new password and confirm password
        </div>'
    ]);
}





