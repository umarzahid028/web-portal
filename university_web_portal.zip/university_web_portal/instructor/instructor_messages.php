<?php 
require_once '../main/includes/init.php';
require_once '../main/session.php';
require_once('../main/header.php'); 
require_once('../main/css.php'); 

if (isset($_SESSION['logged_in'])) {
      if ($_SESSION['logged_in']['account_type'] == 'instructor') {
           
           //return header("Location: profile.php");
      }
      elseif ($_SESSION['logged_in']['account_type'] == 'student') {
          
           return header("Location: index.php");
      } 
      elseif ($_SESSION['logged_in']['account_type'] == 'admin') {
          
           return header("Location: ../admin/index.php");
      } 
 } 

?>
<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>
<style type="text/css">
  .nav_color{background-color: #000000;}
</style>
  <body class="nav-sm" style="background-image:url(../banner1.jpg);">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view nav_color">
            <div class="navbar nav_title nav_color">
              <a href="index.php" class="site_title"><i class="fa fa-university"></i></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile">
              <div class="profile_pic">
                <img src="../public/images/user.png" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2>Admin</h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />
            <?php require_once('../main/sidebar_nav.php'); ?>   
        <!-- page content -->
        <div class="right_col" role="main" style="background-color:transparent;">
          <div class="">
            <div class="page-title">
              <div class="title_left">
              </div>
              </div>
            </div>
            
            <!--  -->
            <form method="POST" action="save_instructor_messages.php">
            <input type="hidden" name="session" value="<?php echo $_SESSION['logged_in']['id']; ?>">
            <textarea name="message">Something here ............</textarea>
            <div class="ln_solid"></div>

          <div class="form-group">
              <label class="control-label col-md-1 col-sm-1 col-xs-1" style="color:#fff; font-size: 18px;">Title</label>
              <div class="col-md-2 col-sm-2 col-xs-2">
                  <input type="text" name="title" placeholder="Title" class="form-control" required="yes">
                <span class="form-control-feedback right" aria-hidden="true"><i class="fa fa-eyedropper"></i></span>
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-1 col-sm-1 col-xs-1" style="color:#fff; fosnt-size: 18px;">Class</label>
              <div class="col-md-2 col-sm-2 col-xs-2">
                <select class="form-control" name="class-id" required="required">
                  <?php $instructor->getClasses($db); ?>
                </select>
                <span class="form-control-feedback right" aria-hidden="true"><i class="fa fa-eyedropper"></i></span>
              </div>
            </div>

              <div class="form-group">
              <label class="control-label col-md-1 col-sm-1 col-xs-1" style="color:#fff; font-size: 18px;">Section</label>
              <div class="col-md-2 col-sm-2 col-xs-2">
                <select class="form-control" name="section" required="required">
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="C">C</option> 
                  <option value="D">D</option>
                </select>
                <span class="form-control-feedback right" aria-hidden="true"><i class="fa fa-eyedropper"></i></span>
              </div>
            </div>
            
            <br>
            <br>
            <br>
            <br>
            <div class="form-group">
              <div class="col-md-12 ">
                <button type="submit" class="btn btn-success btn-lg" >Submit</button>
              </div>
            </div>

                </div>
              </div>
              </form>
            </div>

            <!--  -->

            
					           
                        
                      
                    </div>

                  </div>
                </div>
              </div>                
          <div class="clearfix"></div>
        </div>
        <!-- /page content -->

        
      </div>
    </div>

    



<!-- footer content -->
       <?php require_once('../main/footer.php');?>
        <!-- /footer content --><!-- jQuery -->
    
<!-- JavaScript files --> 
  <?php require_once('../main/js.php');?>
 <!-- JavaScript files-->



 <script>
      $(document).ready(function() {
        function initToolbarBootstrapBindings() {
          var fonts = ['Serif', 'Sans', 'Arial', 'Arial Black', 'Courier',
              'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande', 'Lucida Sans', 'Tahoma', 'Times',
              'Times New Roman', 'Verdana'
            ],
            fontTarget = $('[title=Font]').siblings('.dropdown-menu');
          $.each(fonts, function(idx, fontName) {
            fontTarget.append($('<li><a data-edit="fontName ' + fontName + '" style="font-family:\'' + fontName + '\'">' + fontName + '</a></li>'));
          });
          $('a[title]').tooltip({
            container: 'body'
          });
          $('.dropdown-menu input').click(function() {
              return false;
            })
            .change(function() {
              $(this).parent('.dropdown-menu').siblings('.dropdown-toggle').dropdown('toggle');
            })
            .keydown('esc', function() {
              this.value = '';
              $(this).change();
            });

          $('[data-role=magic-overlay]').each(function() {
            var overlay = $(this),
              target = $(overlay.data('target'));
            overlay.css('opacity', 0).css('position', 'absolute').offset(target.offset()).width(target.outerWidth()).height(target.outerHeight());
          });

          if ("onwebkitspeechchange" in document.createElement("input")) {
            var editorOffset = $('#editor').offset();

            $('.voiceBtn').css('position', 'absolute').offset({
              top: editorOffset.top,
              left: editorOffset.left + $('#editor').innerWidth() - 35
            });
          } else {
            $('.voiceBtn').hide();
          }
        }

        function showErrorAlert(reason, detail) {
          var msg = '';
          if (reason === 'unsupported-file-type') {
            msg = "Unsupported format " + detail;
          } else {
            console.log("error uploading file", reason, detail);
          }
          $('<div class="alert"> <button type="button" class="close" data-dismiss="alert">&times;</button>' +
            '<strong>File upload error</strong> ' + msg + ' </div>').prependTo('#alerts');
        }

        initToolbarBootstrapBindings();

        $('#editor').wysiwyg({
          fileUploadError: showErrorAlert
        });

        window.prettyPrint;
        prettyPrint();
      });
    </script>
    