<?php
require_once '../main/includes/init.php';
require_once '../main/session.php';
require_once('../main/header.php'); 
require_once('../main/css.php'); 

if (isset($_SESSION['logged_in'])) {
      if ($_SESSION['logged_in']['account_type'] == 'instructor') {
           
           //return header("Location: profile.php");
      }
      elseif ($_SESSION['logged_in']['account_type'] == 'student') {
          
           return header("Location: index.php");
      } 
      elseif ($_SESSION['logged_in']['account_type'] == 'admin') {
          
           return header("Location: ../admin/index.php");
      } 
 } 


?>
<style type="text/css">
  .nav_color{background-color: #000000;}
</style>
  <body class="nav-sm" style="background-image:url(../banner1.jpg);">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view nav_color">
            <div class="navbar nav_title nav_color">
              <a href="profile.php" class="site_title"><i class="fa fa-university"></i></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile">
              <div class="profile_pic">
                <img src="../public/images/user.png" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2>Admin</h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />
            <?php require_once('../main/sidebar_nav.php'); 
            $session = $_SESSION['logged_in']['id'];
            $status = $instructor->getInstructorInfo($session, $db);
            

            ?>  


        <!-- page content -->
        <div class="right_col" role="main" style="background-color:transparent;">
          <div class="">
            <div class="page-title">
              <div class="title_left">
              </div>
              </div>
            </div>

            

            <div class="">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel" style="background:rgba(1, 2, 1, 0.6);">
                  
                    
                    
                    <div class="clearfix"></div>
                  
                  <div class="x_content">
            

					
					

	
			



                    <div class="" role="tabpanel" data-example-id="togglable-tabs">
                      
                      
                      <div id="myTabContent" class="tab-content">
                        <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
                        
        
        
              
            <!-- My profile -->
       
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>My Profile</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar">
                          <!-- Current avatar -->
                          <img class="img-responsive avatar-view" src="../public/images/user.png" alt="Avatar" title="<?php echo $status->instructor_name; ?>">
                        </div>
                      </div>
                      <h3><?php echo $status->instructor_name?></h3>

                      <ul class="list-unstyled user_data">
                        <li>
                          <i class="fa fa-envelope" aria-hidden="true"></i>
                            <?php echo $status->instructor_email?>
                        </li>

                        <li>
                          <i class="fa fa-credit-card user-profile-icon"></i> <?php echo $status->instructor_code?>
                        </li>

                        <li class="m-top-xs">
                          <i class="fa fa-external-link user-profile-icon"></i>
                          <a href="#" target="_blank">superior.edu.pk</a>
                        </li>
                      </ul>

        

                      
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12">

                      <div class="" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                          <li role="presentation" class="active"><a href="#tab_profile2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Personal info</a>
                          </li>
                          <li role="presentation" ><a href="#tab_profile3" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">University </a>
                          </li>
                        </ul>
                        <div id="myTabContent" class="tab-content">
                          
                          <div role="tabpanel" class="tab-pane fade active in" id="tab_profile2" aria-labelledby="profile-tab">

                            
                            <table class="data table table-striped no-margin">
                              <tbody>
                                <tr>
                                  <td><b>Full Name</b></td>
                                  <td><?php echo $status->instructor_name?></td>
                                </tr>
                                <tr>
                                  <td><b>Code / ID</b></td>
                                  <td><?php echo $status->instructor_code?></td>
                                </tr>
                                <tr>
                                  <td><b>CNIC</b></td>
                                  <td><?php echo $status->instructor_cnic?></td>
                                </tr>
                                <tr>
                                  <td><b>Gender</b></td>
                                  <td><?php echo $status->instructor_gender?></td>
                                </tr>
                                <tr>
                                  <td><b>Qualification</b></td>
                                  <td><?php echo $status->instructor_qualification?></td>
                                </tr>
                                <tr>
                                  <td><b>Major Subject</b></td>
                                  <td><?php echo $status->major_subject?></td>
                                </tr>
                              </tbody>
                            </table>
                            <!-- end user projects -->

                          </div>
                          <div role="tabpanel" class="tab-pane fade" id="tab_profile3" aria-labelledby="profile-tab">
                            <h1>University Notics</h1>
                            <?php $admin->getUniversityNoyics($db); ?>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              
          </div>
        </div>
        <!-- /my profile -->
      </div>
      
                                    
                                       


                        
                        
                      </div>
                    </div>

                  </div>
                </div>
              </div>
      
          <div class="clearfix"></div>
        </div>
        <!-- /page content -->

        
      </div>
    </div>

    <div id="custom_notifications" class="custom-notifications dsp_none">
      <ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
      </ul>
      <div class="clearfix"></div>
      <div id="notif-group" class="tabbed_notifications"></div>
    </div>



<!-- footer content -->
       <?php require_once('../main/footer.php');?>
        <!-- /footer content --><!-- jQuery -->
    
<!-- JavaScript files --> 
  <?php require_once('../main/js.php');?>
 <!-- JavaScript files-->



    
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            