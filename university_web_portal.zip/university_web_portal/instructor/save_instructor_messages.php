<?php 
require_once '../main/includes/init.php';

$status = $instructor->instructorMassagesForstufents($_POST, $db);

//debug($status);

header("Location: instructor_messages.php");