<?php
session_start();

if (isset($_SESSION['logged_in'])) {
      if ($_SESSION['logged_in']['account_type'] == 'instructor') {
           
           return header("Location: instructor/profile.php");
      }
      elseif ($_SESSION['logged_in']['account_type'] == 'student') {
          
           return header("Location: main/index.php");
      } 
 } 

    
    

 ?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Superior University Web Portal FSD</title>
  <link rel="shortcut icon" href="public/images/logo.png">
  <link rel="stylesheet" href="public/css/login.css">


</head>
<body>
  <div id="logo"> 
  <h1><i>Superior Univarsity FSD<br>Student Portal</i></h1>
</div> 
<section class="stark-login">
  <div class="parent">
  <form action="main/auth.php" method="POST" class="form">	
    <div id="fade-box">
      <input type="text" name="user-id" id="username" placeholder="F00-00-000">
        <input type="password" placeholder="Password" name="password">
          <input type="submit" name="submit" value="Log In">
          <a href="forgot-password.php" style="font-size: 18px; text-decoration: none; color: gray">Forgot Your Password?</a>
               
      </div>
      </form>
      </div>
<div class="footer">
  
</div>
      
      <div class="hexagons">
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <br>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <span>&#x2B22;</span>
          <br>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span> 
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            <span>&#x2B22;</span>
            
            <br>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <span>&#x2B22;</span>
              <br>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
                <span>&#x2B22;</span>
              </div>      
            </section> 
            <div id="circle1">
              <div id="inner-cirlce1">
                <h2></h2>
              </div>
            </div>
            <script src="public/js/jquery.min.js"></script>
            <script src="public/js/script.js"></script>
    

</body>
</html>
